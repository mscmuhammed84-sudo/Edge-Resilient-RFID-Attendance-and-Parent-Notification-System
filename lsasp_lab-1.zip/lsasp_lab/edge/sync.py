import random
import uuid
from typing import Optional

from lsasp.errors import TransportError
from lsasp.protocol import Cfg, make_batch
from .db import EdgeDB


class SyncManager:
    """Store-and-forward uploader (manuscript Section 3.2, step 4).

    * runs every `interval_s` while things go well;
    * exponential back-off with jitter after a failure, capped at `cap_s`;
    * a fresh transmission time T_tx is created for EVERY attempt, so records that
      waited in the buffer are not penalised by their age (v2 only);
    * result handling per record: acknowledged -> synced=1; permanent rejection ->
      quarantined (synced=2); anything else stays pending."""

    def __init__(self, db: EdgeDB, transport, clock, cfg: Cfg, key: bytes, terminal_id: str,
                 batch_size: int = 50, interval_s: int = 300, base_s: int = 30, cap_s: int = 300,
                 rng: Optional[random.Random] = None):
        self.db, self.transport, self.clock, self.cfg = db, transport, clock, cfg
        self.key, self.tid = key, terminal_id
        self.batch_size, self.interval_s, self.base_s, self.cap_s = batch_size, interval_s, base_s, cap_s
        self.rng = rng or random.Random(0)
        self.fails = 0
        self.next_ms = 0
        self.stats = {"batches": 0, "transport_errors": 0, "batch_errors": 0}

    def _backoff_s(self) -> float:
        return min(self.cap_s, self.base_s * (2 ** (self.fails - 1))) * (1 + 0.25 * self.rng.random())

    def send_one_batch(self) -> str:
        """Returns 'empty' | 'ok' | 'rejected' | 'transport_error' | 'batch_error'."""
        rows = self.db.unsynced(self.batch_size)
        if not rows:
            return "empty"
        now = self.clock.now_ms()
        batch = make_batch(self.cfg, self.key, self.tid, rows, now, uuid.uuid4().hex)
        self.stats["batches"] += 1
        try:
            resp = self.transport.send(batch)
        except TransportError:
            self.stats["transport_errors"] += 1
            return "transport_error"
        if resp.get("batch_error"):
            self.stats["batch_errors"] += 1
            for r in rows:
                self.db.bump_attempts(r["nonce"], resp["batch_error"])
            self.db.commit()
            return "batch_error"
        all_ok = True
        by_nonce = {x["nonce"]: x for x in resp.get("results", [])}
        for r in rows:
            x = by_nonce.get(r["nonce"])
            if x is None:
                self.db.bump_attempts(r["nonce"], "no_result"); all_ok = False
            elif x["status"] in ("accepted", "duplicate"):
                self.db.mark(r["nonce"], 1, None)
            elif x.get("permanent"):
                self.db.mark(r["nonce"], 2, x["reason"])        # quarantined: resolved, no retry
            else:
                self.db.bump_attempts(r["nonce"], x["reason"]); all_ok = False
        self.db.commit()
        return "ok" if all_ok else "rejected"

    def tick(self) -> Optional[str]:
        """Call frequently; does nothing until the next scheduled attempt is due."""
        now = self.clock.now_ms()
        if now < self.next_ms:
            return None
        while True:
            last = self.send_one_batch()
            if last == "ok" and self.db.counts()["pending"] > 0:
                continue            # keep draining while batches are fully resolved
            break
        if last in ("empty", "ok"):
            self.fails = 0
            self.next_ms = now + self.interval_s * 1000
        else:
            self.fails += 1
            self.next_ms = now + int(self._backoff_s() * 1000)
        return last
