from dataclasses import dataclass, field
from typing import Optional

from lsasp.protocol import Cfg, make_packet
from .classify import TimeWindows, classify
from .db import EdgeDB


class Feedback:
    """LCD/buzzer interface. Replace with a GPIO/I2C implementation on the Pi."""

    def show(self, msg: str) -> None: ...
    def beep(self, kind: str) -> None: ...


@dataclass
class RecordingFeedback(Feedback):
    log: list = field(default_factory=list)

    def show(self, msg): self.log.append(("lcd", msg))
    def beep(self, kind): self.log.append(("beep", kind))


class Terminal:
    def __init__(self, db: EdgeDB, cfg: Cfg, key: bytes, terminal_id: str, clock,
                 windows: Optional[TimeWindows] = None, feedback: Optional[Feedback] = None,
                 debounce_s: int = 30):
        self.db, self.cfg, self.key, self.tid, self.clock = db, cfg, key, terminal_id, clock
        self.w = windows or TimeWindows()
        self.fb = feedback or Feedback()
        self.debounce_ms = debounce_s * 1000

    def handle_scan(self, card_uid: str) -> dict:
        now = self.clock.now_ms()
        sid = self.db.student_for_card(card_uid)
        if sid is None:
            self.db.log_invalid(card_uid, "invalid_card", now)
            self.fb.show("Invalid card"); self.fb.beep("error")
            return {"result": "invalid_card"}
        last = self.db.last_scan_ms(sid)
        if last is not None and now - last < self.debounce_ms:
            return {"result": "debounced", "student_id": sid}
        status = classify(now, self.w)
        if status == "invalid_time":
            self.db.log_invalid(card_uid, "invalid_time", now)
            self.fb.show("Outside time window"); self.fb.beep("error")
            return {"result": "invalid_time", "student_id": sid}
        pkt = make_packet(self.cfg, self.key, sid, now, status, self.tid)
        self.db.insert_record(pkt)          # durable BEFORE any feedback / network
        self.fb.show(f"OK: {status}"); self.fb.beep("ok")
        return {"result": "recorded", "status": status, "student_id": sid, "nonce": pkt["nonce"]}
