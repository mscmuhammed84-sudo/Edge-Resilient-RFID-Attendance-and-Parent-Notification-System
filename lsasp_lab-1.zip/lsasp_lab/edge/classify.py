"""Rule-based time-window classification of a scan (manuscript Section 3.2, step 1).
Default windows are ILLUSTRATIVE; the school administrator configures real ones."""
from dataclasses import dataclass


def _minutes(hhmm: str) -> int:
    h, m = hhmm.split(":")
    return int(h) * 60 + int(m)


@dataclass(frozen=True)
class TimeWindows:
    arrival_start: str = "07:00"     # T_start
    grace_min: int = 15              # T_grace  (on-time until arrival_start + grace)
    arrival_end: str = "09:00"       # T_arrival_end (late until here)
    departure_start: str = "12:00"
    departure_end: str = "15:00"
    tz_offset_min: int = 180         # Iraq: UTC+3, no DST


def local_minute_of_day(t_ms: int, tz_offset_min: int) -> float:
    return ((t_ms // 1000 + tz_offset_min * 60) % 86400) / 60.0


def classify(t_ms: int, w: TimeWindows) -> str:
    m = local_minute_of_day(t_ms, w.tz_offset_min)
    a0, a1 = _minutes(w.arrival_start), _minutes(w.arrival_end)
    on_time_end = a0 + w.grace_min
    if a0 <= m < on_time_end:
        return "on_time"
    if on_time_end <= m <= a1:
        return "late"
    if _minutes(w.departure_start) <= m <= _minutes(w.departure_end):
        return "departure"
    return "invalid_time"
