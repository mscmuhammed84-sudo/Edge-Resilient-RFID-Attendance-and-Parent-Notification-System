import json
import urllib.error
import urllib.request

from lsasp.errors import TransportError


class HttpTransport:
    def __init__(self, url: str, timeout: float = 15.0):
        self.url, self.timeout = url, timeout

    def send(self, batch: dict) -> dict:
        req = urllib.request.Request(self.url, data=json.dumps(batch).encode(),
                                     headers={"Content-Type": "application/json"}, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r:
                return json.loads(r.read())
        except (urllib.error.URLError, TimeoutError, ConnectionError, ValueError) as e:
            raise TransportError(str(e)) from e
