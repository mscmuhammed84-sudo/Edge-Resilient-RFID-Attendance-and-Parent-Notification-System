"""RFID reader abstraction.

MockReader is used in tests/simulations. MFRC522Reader wraps the common `mfrc522`
Raspberry Pi library and has NOT been tested on hardware in this project."""
from collections import deque
from typing import Optional


class MockReader:
    def __init__(self, uids=()):
        self.q = deque(uids)

    def push(self, uid: str) -> None:
        self.q.append(uid)

    def read_uid(self) -> Optional[str]:
        return self.q.popleft() if self.q else None


class MFRC522Reader:  # pragma: no cover - requires Raspberry Pi hardware
    def __init__(self):
        from mfrc522 import SimpleMFRC522  # pip install mfrc522 (on the Pi)
        self._r = SimpleMFRC522()

    def read_uid(self) -> Optional[str]:
        uid = self._r.read_id_no_block()
        return None if uid is None else format(uid, "x")


def scan_loop(reader, terminal, sleep, should_stop=lambda: False, poll_s: float = 0.1):  # pragma: no cover
    while not should_stop():
        uid = reader.read_uid()
        if uid:
            terminal.handle_scan(uid)
        else:
            sleep(poll_s)
