-- Edge terminal schema (SQLite). Student IDs are pseudonymous; parent e-mail
-- addresses are NOT stored on the terminal (they live in the cloud service).
CREATE TABLE IF NOT EXISTS cards(
    card_uid   TEXT PRIMARY KEY,
    student_id TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS attendance(
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id  TEXT    NOT NULL,
    t_event_ms  INTEGER NOT NULL,
    status      TEXT    NOT NULL CHECK(status IN ('on_time','late','departure')),
    terminal_id TEXT    NOT NULL,
    nonce       TEXT    NOT NULL UNIQUE,
    token       TEXT    NOT NULL,
    pkt_hash    TEXT    NOT NULL,
    -- 0 = pending, 1 = acknowledged by cloud, 2 = quarantined (permanent rejection)
    synced      INTEGER NOT NULL DEFAULT 0 CHECK(synced IN (0,1,2)),
    attempts    INTEGER NOT NULL DEFAULT 0,
    last_error  TEXT
);
CREATE INDEX IF NOT EXISTS idx_attendance_pending ON attendance(synced, id);
CREATE INDEX IF NOT EXISTS idx_attendance_student ON attendance(student_id, t_event_ms);

CREATE TABLE IF NOT EXISTS invalid_scans(
    id       INTEGER PRIMARY KEY AUTOINCREMENT,
    card_uid TEXT,
    reason   TEXT    NOT NULL,   -- invalid_card | invalid_time
    t_ms     INTEGER NOT NULL
);
