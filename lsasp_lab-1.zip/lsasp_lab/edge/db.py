import os
import sqlite3
from typing import Optional

SCHEMA = os.path.join(os.path.dirname(__file__), "schema.sql")


class EdgeDB:
    def __init__(self, path: str = ":memory:", durable: bool = True):
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        if path != ":memory:":
            self.conn.execute("PRAGMA journal_mode=WAL")
        # FULL fsyncs every commit (safest against power loss); NORMAL is faster.
        self.conn.execute("PRAGMA synchronous=%s" % ("FULL" if durable else "NORMAL"))
        with open(SCHEMA, encoding="utf8") as f:
            self.conn.executescript(f.read())
        self.conn.commit()

    # cards -------------------------------------------------------------------
    def authorize(self, card_uid: str, student_id: str) -> None:
        self.conn.execute("INSERT OR REPLACE INTO cards VALUES(?,?)", (card_uid, student_id))
        self.conn.commit()

    def student_for_card(self, card_uid: str) -> Optional[str]:
        r = self.conn.execute("SELECT student_id FROM cards WHERE card_uid=?", (card_uid,)).fetchone()
        return r["student_id"] if r else None

    # attendance --------------------------------------------------------------
    def insert_record(self, pkt: dict) -> None:
        self.conn.execute(
            "INSERT INTO attendance(student_id,t_event_ms,status,terminal_id,nonce,token,pkt_hash)"
            " VALUES(?,?,?,?,?,?,?)",
            (pkt["student_id"], pkt["t_event"], pkt["status"], pkt["terminal_id"],
             pkt["nonce"], pkt["token"], pkt["hash"]))
        self.conn.commit()

    def last_scan_ms(self, student_id: str) -> Optional[int]:
        r = self.conn.execute("SELECT MAX(t_event_ms) m FROM attendance WHERE student_id=?",
                              (student_id,)).fetchone()
        return r["m"]

    def unsynced(self, limit: int) -> list[dict]:
        rows = self.conn.execute(
            "SELECT student_id,t_event_ms,status,terminal_id,nonce,token,pkt_hash FROM attendance"
            " WHERE synced=0 ORDER BY id LIMIT ?", (limit,)).fetchall()
        return [{"student_id": r["student_id"], "t_event": r["t_event_ms"], "nonce": r["nonce"],
                 "status": r["status"], "terminal_id": r["terminal_id"], "token": r["token"],
                 "hash": r["pkt_hash"]} for r in rows]

    def mark(self, nonce: str, synced: int, error: Optional[str] = None) -> None:
        self.conn.execute("UPDATE attendance SET synced=?, last_error=? WHERE nonce=?",
                          (synced, error, nonce))

    def bump_attempts(self, nonce: str, error: Optional[str]) -> None:
        self.conn.execute("UPDATE attendance SET attempts=attempts+1, last_error=? WHERE nonce=?",
                          (error, nonce))

    def commit(self) -> None:
        self.conn.commit()

    def log_invalid(self, card_uid: Optional[str], reason: str, t_ms: int) -> None:
        self.conn.execute("INSERT INTO invalid_scans(card_uid,reason,t_ms) VALUES(?,?,?)",
                          (card_uid, reason, t_ms))
        self.conn.commit()

    def counts(self) -> dict:
        r = self.conn.execute(
            "SELECT SUM(synced=0) p, SUM(synced=1) a, SUM(synced=2) q, COUNT(*) n FROM attendance").fetchone()
        return {"pending": r["p"] or 0, "acknowledged": r["a"] or 0,
                "quarantined": r["q"] or 0, "total": r["n"] or 0}
