"""Micro-benchmarks. LAB MACHINE numbers only -- NOT Raspberry Pi 4 field measurements."""
import hashlib, hmac, os, platform, random, sqlite3, statistics, sys, tempfile, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from lsasp.protocol import V1, V2, Validator, make_packet, make_batch, terminal_key, new_nonce
from lsasp.clock import VirtualClock


def timeit(fn, n=5000, warm=200):
    for _ in range(warm): fn()
    xs = []
    for _ in range(n):
        t = time.perf_counter_ns(); fn(); xs.append((time.perf_counter_ns() - t) / 1e3)
    xs.sort()
    return {"mean_us": round(statistics.mean(xs), 2), "p50_us": round(xs[n // 2], 2),
            "p95_us": round(xs[int(n * .95)], 2), "p99_us": round(xs[int(n * .99)], 2), "n": n}


def machine():
    cpu = ""
    try:
        cpu = [l.split(":")[1].strip() for l in open("/proc/cpuinfo") if l.startswith("model name")][0]
    except Exception: pass
    return {"cpu": cpu, "cores": os.cpu_count(), "python": platform.python_version(),
            "sqlite": sqlite3.sqlite_version, "os": platform.platform()}


def run(n=5000):
    key = b"k" * 32; msg = b"S123" + b"1" * 13 + b"x" * 16 + b"on_time" + b"T1"
    out = {"machine": machine(), "results": {}}
    R = out["results"]
    R["sha256_over_record"] = timeit(lambda: hashlib.sha256(msg).digest(), n)
    R["hmac_sha256_over_record"] = timeit(lambda: hmac.new(key, msg, hashlib.sha256).digest(), n)
    R["nonce_generation_16B"] = timeit(lambda: os.urandom(16), n)
    for name, cfg in (("v1", V1), ("v2", V2)):
        k = terminal_key(cfg, b"m" * 32, "T1")
        R[f"make_packet_{name}"] = timeit(lambda: make_packet(cfg, k, "S1", 1772341200000, "on_time", "T1"), n)
    # validation cost of a 50-record batch
    for name, cfg in (("v1", V1), ("v2", V2)):
        k = terminal_key(cfg, b"m" * 32, "T1"); c = VirtualClock(); now = c.now_ms()
        def one():
            v = Validator(cfg, b"m" * 32, {"T1"})
            pk = [make_packet(cfg, k, f"S{i}", now, "on_time", "T1") for i in range(50)]
            b = make_batch(cfg, k, "T1", pk, now, "b")
            t = time.perf_counter_ns(); v.handle_batch(b, now); return time.perf_counter_ns() - t
        xs = sorted(one() / 1e3 for _ in range(300))
        R[f"validate_batch50_{name}"] = {"mean_us": round(statistics.mean(xs), 1), "p50_us": round(xs[150], 1),
                                         "p95_us": round(xs[285], 1), "p99_us": round(xs[297], 1), "n": 300}
    # durable SQLite insert, file-backed
    for sync in ("FULL", "NORMAL"):
        d = tempfile.mkdtemp(); con = sqlite3.connect(os.path.join(d, "b.db"))
        con.execute("PRAGMA journal_mode=WAL"); con.execute(f"PRAGMA synchronous={sync}")
        con.execute("create table a(id integer primary key, n blob unique, s text)")
        def ins():
            con.execute("insert into a(n,s) values(?,?)", (os.urandom(16), "on_time")); con.commit()
        R[f"sqlite_insert_commit_sync_{sync}"] = timeit(ins, 1000, 50)
    return out


if __name__ == "__main__":
    import json
    o = run(int(sys.argv[1]) if len(sys.argv) > 1 else 5000)
    print(json.dumps(o, indent=1))
