"""Attack, fault and scenario experiments. Everything here is a LABORATORY
experiment on synthetic data; none of it is school data."""
from __future__ import annotations

import hashlib
import random
import statistics
from dataclasses import replace

from edge.db import EdgeDB
from edge.sync import SyncManager
from edge.terminal import Terminal
from lsasp.clock import VirtualClock
from lsasp.protocol import (STATUSES, V1, V2, Validator, _rec_enc, _v1_hash, make_batch,
                            make_packet, terminal_key, variant)
from sim.link import SimTransport

N_TRIALS = 1000
MIN = 60 * 1000


# ------------------------------------------------------------------ harness
class Ctx:
    def __init__(self, cfg, rng: random.Random):
        self.cfg, self.rng = cfg, rng
        self.c = VirtualClock()
        self.master = rng.randbytes(32)
        self.v = Validator(cfg, self.master, {"T1", "T2"})
        self.keys = {t: terminal_key(cfg, self.master, t) for t in ("T1", "T2")}
        self.n = 0

    def pkt(self, tid="T1", t=None, status=None, sid=None, key=None):
        self.n += 1
        return make_packet(self.cfg, key or self.keys[tid], sid or f"S{self.rng.randrange(10**6)}",
                           self.c.now_ms() if t is None else t,
                           status or self.rng.choice(STATUSES), tid, nonce=self.rng.randbytes(16).hex())

    def batch(self, packets, tid="T1", t_tx=None, key=None):
        self.n += 1
        return make_batch(self.cfg, key or self.keys[tid], tid, packets,
                          self.c.now_ms() if t_tx is None else t_tx, f"b{self.n}")

    def submit(self, batch):
        return self.v.handle_batch(batch, self.c.now_ms())


def public_hash(cfg, p):
    """What an attacker can recompute without any key (the packet hash is unkeyed)."""
    if cfg.mac == "v1":
        return _v1_hash(p["token"], p["status"], p["terminal_id"])
    enc = _rec_enc(p["terminal_id"], p["student_id"], p["t_event"], p["nonce"], p["status"])
    return hashlib.sha256(enc + bytes.fromhex(p["token"])).hexdigest()


def stored(ctx, nonce):
    return [r for r in ctx.v.accepted_records if r["nonce"] == nonce]


# ------------------------------------------------------------------ attacks
# Each attack returns True when the ATTACKER'S GOAL was achieved.
def a_replay_immediate(ctx):
    p = ctx.pkt(); b = ctx.batch([p]); ctx.submit(b)
    ctx.c.advance_s(30); ctx.submit(b)
    return len(stored(ctx, p["nonce"])) > 1


def a_replay_after_window(ctx):
    p = ctx.pkt(); b = ctx.batch([p]); ctx.submit(b)
    ctx.c.advance_s(600); ctx.submit(b)
    return len(stored(ctx, p["nonce"])) > 1


def a_replay_after_cloud_restart(ctx):
    p = ctx.pkt(); b = ctx.batch([p]); ctx.submit(b)
    ctx.v.restart(); ctx.c.advance_s(30); ctx.submit(b)
    return len(stored(ctx, p["nonce"])) > 1


def _tamper(ctx, field, newval):
    p = ctx.pkt(status="late"); q = dict(p); q[field] = newval(p) if callable(newval) else newval
    q["hash"] = public_hash(ctx.cfg, q)       # attacker recomputes the unkeyed hash
    ctx.submit(ctx.batch([q]))
    r = stored(ctx, p["nonce"])
    return bool(r) and r[0][field] == q[field]


def a_tamper_status(ctx): return _tamper(ctx, "status", "on_time")
def a_tamper_terminal(ctx): return _tamper(ctx, "terminal_id", "T2")
def a_tamper_student(ctx): return _tamper(ctx, "student_id", "S-victim")
def a_tamper_time(ctx): return _tamper(ctx, "t_event", lambda p: p["t_event"] + 1000)


def a_inject_without_key(ctx):
    wrong = ctx.rng.randbytes(32)
    p = ctx.pkt(key=wrong, status="on_time", sid="S-forged")
    ctx.submit(ctx.batch([p], key=wrong))
    return bool(stored(ctx, p["nonce"]))


def a_bitflip_in_transit(ctx):
    p = ctx.pkt(); q = dict(p)
    f = ctx.rng.choice(["student_id", "t_event", "nonce", "status", "terminal_id", "token", "hash"])
    if f == "t_event": q[f] += ctx.rng.choice([-1, 1]) * ctx.rng.randrange(1, 10**6)
    elif f == "status": q[f] = ctx.rng.choice([s for s in STATUSES if s != p[f]])
    else:
        s = list(q[f]); i = ctx.rng.randrange(len(s)); s[i] = "g" if s[i] != "g" else "h"
        if f in ("nonce", "token", "hash"):
            s[i] = "0" if s[i] != "0" else "1"
        q[f] = "".join(s)
    ctx.submit(ctx.batch([q]))
    r = stored(ctx, p["nonce"]) or stored(ctx, q["nonce"])
    return bool(r) and r[0] != dict(p, accepted_ms=r[0]["accepted_ms"])


def a_refresh_stale_batch(ctx):
    """Intercept a batch, hold it for 10 minutes, then refresh T_tx and forward it."""
    cfg = ctx.cfg
    if cfg.time_model != "event_tx":
        return None                                    # v1 has no transmission time
    p = ctx.pkt(); b = ctx.batch([p])
    ctx.c.advance_s(600)
    b2 = dict(b); b2["t_tx"] = ctx.c.now_ms()          # attacker has no key: old batch_mac is reused
    ctx.submit(b2)
    return bool(stored(ctx, p["nonce"]))


def a_key_compromise_other_terminal(ctx):
    """Key extracted from terminal T1 (e.g., SD card) is used to forge records for T2."""
    k1 = ctx.keys["T1"]
    p = make_packet(ctx.cfg, k1, "S-forged", ctx.c.now_ms(), "on_time", "T2", nonce=ctx.rng.randbytes(16).hex())
    ctx.submit(make_batch(ctx.cfg, k1, "T2", [p], ctx.c.now_ms(), "bx"))
    r = stored(ctx, p["nonce"])
    return bool(r) and r[0]["terminal_id"] == "T2"


def a_record_suppression(ctx):
    """On-path attacker drops one record from a two-record batch and forwards the rest.
    Success: the cloud accepts the shortened batch (the dropped record never arrives)."""
    p1, p2 = ctx.pkt(), ctx.pkt()
    b = ctx.batch([p1, p2]); b2 = dict(b, records=[p1])
    ctx.submit(b2)
    return bool(stored(ctx, p1["nonce"])) and not stored(ctx, p2["nonce"])


def a_fuzz_robustness(ctx):
    """Random malformed batches. Success (for the attacker): the validator raises."""
    junk = [None, 5, "x", [], {}, {"records": 5}, {"records": [None, 3, "a"]},
            {"records": [{}], "t_tx": "x"}, {"records": [{"student_id": 1}], "t_tx": 1, "terminal_id": 7},
            {"records": [{"student_id": "S", "t_event": 1.5, "nonce": "zz", "status": "late",
                          "terminal_id": "T1", "token": "q", "hash": "q"}], "t_tx": ctx.c.now_ms(),
             "terminal_id": "T1", "batch_id": "b", "batch_mac": 7}]
    try:
        ctx.submit(ctx.rng.choice(junk))
    except Exception:
        return True
    return False


ATTACKS = [
    ("A1 replay of an accepted batch (30 s later)", a_replay_immediate),
    ("A2 replay of an accepted batch (10 min later)", a_replay_after_window),
    ("A3 replay after cloud cold start (30 s later)", a_replay_after_cloud_restart),
    ("A4 tamper Status (late -> on_time), hash recomputed", a_tamper_status),
    ("A5 tamper Terminal_ID (T1 -> T2), hash recomputed", a_tamper_terminal),
    ("A6 tamper Student_ID, hash recomputed", a_tamper_student),
    ("A7 tamper event time, hash recomputed", a_tamper_time),
    ("A8 inject forged record without the key", a_inject_without_key),
    ("A9 random bit-flip in transit", a_bitflip_in_transit),
    ("A10 refresh stale batch (forge T_tx)", a_refresh_stale_batch),
    ("A11 forge for another terminal with an extracted key", a_key_compromise_other_terminal),
    ("A12 drop a record from a batch in transit", a_record_suppression),
    ("A13 malformed or fuzzed batch crashes the validator", a_fuzz_robustness),
]


def run_attacks(cfg, n=N_TRIALS, seed=2026):
    out = {}
    for name, fn in ATTACKS:
        rng = random.Random(f"{seed}-{cfg.name}-{name}")
        wins = tot = 0
        for _ in range(n):
            r = fn(Ctx(cfg, rng))
            if r is None:
                wins = None; break
            wins += bool(r); tot += 1
        out[name] = {"success": wins, "trials": tot if wins is not None else 0}
    return out


# ------------------------------------------------------------------ operational faults
def f_buffer_delay(cfg, seed=7):
    """A legitimate record waits `d` minutes in the local buffer before upload."""
    res = {}
    for d in (1, 4, 6, 10, 30, 60, 240, 1500):
        ctx = Ctx(cfg, random.Random(seed))
        p = ctx.pkt(); ctx.c.advance_s(d * 60)
        ctx.submit(ctx.batch([p]))
        res[f"{d} min"] = bool(stored(ctx, p["nonce"]))
    return res


def f_batch_poisoning(cfg, n=50, seed=8):
    """Batch of n records, k of them corrupted. Fraction of the LEGITIMATE ones accepted."""
    res = {}
    for k in (0, 1, 2, 5):
        ctx = Ctx(cfg, random.Random(seed))
        recs = [ctx.pkt() for _ in range(n)]
        for i in range(k):
            recs[i * 7 % n] = dict(recs[i * 7 % n], token="00" * 32)
        ctx.submit(ctx.batch(recs))
        res[f"{k} corrupted of {n}"] = f"{len(ctx.v.accepted_records)}/{n - k}"
    return res


def f_clock_skew(cfg, seed=9):
    """Terminal clock wrong by `off` (no RTC). Is the record accepted? (Accepted does not
    mean correct: the cloud cannot tell that an in-window time is wrong.)"""
    res = {}
    for off, label in ((-86400, "-24 h"), (-3600, "-1 h"), (-240, "-4 min"), (0, "0"),
                       (240, "+4 min"), (3600, "+1 h"), (86400, "+24 h")):
        ctx = Ctx(cfg, random.Random(seed))
        p = ctx.pkt(t=ctx.c.now_ms() + off * 1000)
        ctx.submit(ctx.batch([p]))
        res[label] = bool(stored(ctx, p["nonce"]))
    return res


# ------------------------------------------------------------------ system scenarios
class Rig:
    def __init__(self, cfg, n_students, seed=1):
        self.cfg = cfg
        self.c = VirtualClock()
        self.master = random.Random(seed).randbytes(32)
        self.v = Validator(cfg, self.master, {"T1"})
        self.key = terminal_key(cfg, self.master, "T1")
        self.db = EdgeDB()
        for i in range(n_students):
            self.db.authorize(f"c{i}", f"S{i}")
        self.t = Terminal(self.db, cfg, self.key, "T1", self.c)
        self.tr = SimTransport(self.v, self.c)
        self.sm = SyncManager(self.db, self.tr, self.c, cfg, self.key, "T1", rng=random.Random(seed))

    def run(self, scans, horizon_s=8 * 3600, drain_s=6 * 3600):
        """scans: sorted list of (offset_s_from_start, card_uid)."""
        t0 = self.c.now_ms(); i = 0; end = t0 + (horizon_s + drain_s) * 1000
        while True:
            nxt_scan = t0 + scans[i][0] * 1000 if i < len(scans) else None
            cand = [x for x in (nxt_scan, max(self.sm.next_ms, self.c.now_ms())) if x is not None]
            t = min(cand)
            if t > end: break
            self.c.set_ms(int(max(self.c.now_ms(), t)))
            if nxt_scan is not None and t == nxt_scan:
                self.t.handle_scan(scans[i][1]); i += 1
            else:
                self.sm.tick()
            if i >= len(scans) and self.db.counts()["pending"] == 0:
                break
        return self.metrics()

    def metrics(self):
        recs = self.v.accepted_records
        lat = [(r["accepted_ms"] - r["t_event"]) / 1000 for r in recs]
        c = self.db.counts()
        nonces = [r["nonce"] for r in recs]
        return {"recorded": c["total"], "acknowledged_by_terminal": c["acknowledged"],
                "pending_at_end": c["pending"], "quarantined": c["quarantined"],
                "stored_in_cloud": len(recs), "duplicates_in_cloud": len(nonces) - len(set(nonces)),
                "latency_p50_s": round(statistics.median(lat), 1) if lat else None,
                "latency_max_s": round(max(lat), 1) if lat else None}


def _scans(n, start_s, span_s, seed, shuffle_cards=True):
    rng = random.Random(seed)
    ts = sorted(rng.uniform(start_s, start_s + span_s) for _ in range(n))
    cards = list(range(n))
    if shuffle_cards: rng.shuffle(cards)
    return [(t, f"c{c}") for t, c in zip(ts, cards)]


def s_normal_day(cfg):
    r = Rig(cfg, 150)
    arr = _scans(150, 0, 55 * 60, 11)                       # 08:00-09:30 virtual start offsets
    dep = _scans(150, 4.5 * 3600, 90 * 60, 12)              # ~12:30-14:00
    return r.run(sorted(arr + dep), horizon_s=7 * 3600)


def s_outage_one_hour(cfg, n=300):
    r = Rig(cfg, n)
    r.tr.add_outage(r.c.now_ms(), r.c.now_ms() + 62 * 60 * 1000)
    return r.run(_scans(n, 60, 58 * 60, 21), horizon_s=3600)


def s_lost_acks(cfg, n=100):
    r = Rig(cfg, n); r.tr.drop_next_acks = 3
    return r.run(_scans(n, 0, 20 * 60, 31), horizon_s=3600)


def s_poison_first_record(cfg, n=100):
    r = Rig(cfg, n)
    scans = _scans(n, 0, 20 * 60, 41)
    # corrupt one stored row after the scans have been recorded, before the first sync
    first = scans[0][0]
    r.c.advance_s(first); r.t.handle_scan(scans[0][1])
    r.db.conn.execute("UPDATE attendance SET token=? WHERE id=1", ("00" * 32,)); r.db.commit()
    return r.run([(s - first, u) for s, u in scans[1:]], horizon_s=3600)


def s_restart_replay(cfg, n=50):
    r = Rig(cfg, n)
    wire = []
    orig = r.tr.send
    def spy(batch):
        wire.append(batch); return orig(batch)
    r.tr.send = spy
    m = r.run(_scans(n, 0, 10 * 60, 51), horizon_s=1800)
    r.v.restart()
    for b in wire[:2]:                                      # attacker replays captured batches
        r.v.handle_batch(b, r.c.now_ms())
    after = r.metrics()
    return {"before_replay": m["stored_in_cloud"], "after_replay": after["stored_in_cloud"],
            "duplicates_in_cloud": after["duplicates_in_cloud"]}


SCENARIOS = [("S1 normal day: 150 students, 300 events", s_normal_day),
             ("S2 one-hour outage, 300 buffered events", s_outage_one_hour),
             ("S3 first 3 acknowledgments lost, 100 events", s_lost_acks),
             ("S4 one corrupted record at the head of the queue, 100 events", s_poison_first_record),
             ("S5 cloud cold start, then replay of captured batches", s_restart_replay)]


# ------------------------------------------------------------------ ablation configs
BUILD_UP = [
    ("L0 = v1 (as in the manuscript)", V1),
    ("L1 = L0 + HMAC-SHA256 over all fields", variant(V1, name="L1", mac="hmac")),
    ("L2 = L1 + T_event/T_tx + batch HMAC", variant(V1, name="L2", mac="hmac", time_model="event_tx")),
    ("L3 = L2 + per-record validation", variant(V1, name="L3", mac="hmac", time_model="event_tx", per_record=True)),
    ("L4 = L3 + persistent nonce index", variant(V1, name="L4", mac="hmac", time_model="event_tx", per_record=True, nonce_store="persistent")),
    ("L5 = L4 + idempotent acknowledgment", variant(V1, name="L5", mac="hmac", time_model="event_tx", per_record=True, nonce_store="persistent", idempotent=True)),
    ("L6 = L5 + per-terminal keys (= v2)", V2),
]
LEAVE_ONE_OUT = [
    ("v2 without HMAC (v1 token + unkeyed hash)", variant(V2, name="v2-noHMAC", mac="v1")),
    ("v2 without T_event/T_tx separation", variant(V2, name="v2-noTx", time_model="single")),
    ("v2 without per-record validation", variant(V2, name="v2-noPerRec", per_record=False)),
    ("v2 without persistent nonce index", variant(V2, name="v2-noPersist", nonce_store="memory_ttl")),
    ("v2 without idempotent acknowledgment", variant(V2, name="v2-noIdem", idempotent=False)),
    ("v2 without per-terminal keys", variant(V2, name="v2-noPerTermKey", per_terminal_keys=False)),
    ("v2 (all components)", V2),
]


# ------------------------------------------------------------------ baseline sensitivity
TUNED_BASELINES = [
    ("v1, freshness 5 min (as specified)", V1),
    ("v1, freshness 1 h", variant(V1, name="v1-1h", freshness_s=3600)),
    ("v1, freshness 24 h", variant(V1, name="v1-24h", freshness_s=86400)),
    ("v2", V2),
]


def replay_after_restart_by_delay(cfg, seed=5):
    """Does a batch captured earlier and replayed after a cloud restart get accepted again?"""
    res = {}
    for label, secs in (("30 s", 30), ("10 min", 600), ("2 h", 7200), ("25 h", 90000)):
        ctx = Ctx(cfg, random.Random(seed))
        p = ctx.pkt(); b = ctx.batch([p]); ctx.submit(b)
        ctx.v.restart(); ctx.c.advance_s(secs); ctx.submit(b)
        res[label] = len(stored(ctx, p["nonce"])) > 1
    return res
