"""50 simulated school days, 150 virtual students (synthetic workload; no school data).
Every parameter below is an assumption of the simulation, not a measurement."""
import os, random, statistics, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from experiments.suite import Rig, V1, V2, variant
from cloud.notify import Notifier, RecordingMailer

DAY_MS = 86400 * 1000
START_UTC_MS = 1772333100000 - 0  # replaced below by clock default


def pct(xs, q):
    xs = sorted(xs); return xs[min(len(xs) - 1, int(q * len(xs)))] if xs else None


def run(cfg, p_outage, seed, n_students=150, days=50, p_absent=0.04):
    rng = random.Random(f"long-{seed}-{p_outage}")          # same workload and outages for v1 and v2
    r = Rig(cfg, n_students, seed=seed)
    parents = {f"S{i}": {"name": f"Student {i}", "email": f"parent{i}@example.invalid"} for i in range(n_students)}
    mailer = RecordingMailer(); nt = Notifier(parents, mailer); r.v.on_accept = nt.on_accept
    day0 = r.c.now_ms() - 80 * 60 * 1000                    # clock default is 08:00 local -> start days at 06:40
    outages = 0
    for d in range(days):
        start = day0 + d * DAY_MS
        r.c.set_ms(max(r.c.now_ms(), start))
        scans = []
        for i in range(n_students):
            if rng.random() < p_absent: continue
            arr = min(max(rng.gauss(50, 18), 20), 110)       # minutes after 06:40, i.e. 07:00-08:30 (windows: 07:00-09:00)
            scans.append((arr * 60, f"c{i}"))
            scans.append(((5.8 * 60 + rng.uniform(0, 90)) * 60, f"c{i}"))   # departure ~12:28-13:58
        scans.sort()
        if rng.random() < p_outage:
            outages += 1
            dur = rng.uniform(60, 240) if rng.random() < 0.3 else rng.uniform(600, 7200)
            s0 = start + rng.uniform(0, 7 * 3600) * 1000
            r.tr.add_outage(int(s0), int(s0 + dur * 1000))
        r.run(scans, horizon_s=8 * 3600, drain_s=6 * 3600)
        nt.flush()
    m = r.metrics(); recs = r.v.accepted_records
    lat = [(x["accepted_ms"] - x["t_event"]) / 1000 for x in recs]
    nonces = [x["nonce"] for x in recs]
    return {"outage_days": outages, "events": m["recorded"], "stored_in_cloud": m["stored_in_cloud"],
            "not_in_cloud": m["recorded"] - m["stored_in_cloud"], "pending_at_end": m["pending_at_end"],
            "quarantined": m["quarantined"], "terminal_acked": m["acknowledged_by_terminal"],
            "duplicates": len(nonces) - len(set(nonces)), "emails_sent": len(mailer.sent),
            "emails_failed": len(nt.failed),
            "lat_p50_s": round(pct(lat, .5), 1) if lat else None, "lat_p95_s": round(pct(lat, .95), 1) if lat else None,
            "lat_p99_s": round(pct(lat, .99), 1) if lat else None, "lat_max_s": round(max(lat), 1) if lat else None}


V1_24H = variant(V1, name="v1-24h", freshness_s=86400)


def sweep(seeds=tuple(range(1, 11)), probs=(0.0, 0.05, 0.1, 0.3)):
    out = {}
    for p in probs:
        for lab, cfg in (("v1", V1), ("v1-24h", V1_24H), ("v2", V2)):
            out[f"{lab}@p={p}"] = [run(cfg, p, s) for s in seeds]
    return out


if __name__ == "__main__":
    import json; print(json.dumps(sweep(seeds=(1,)), indent=1))
