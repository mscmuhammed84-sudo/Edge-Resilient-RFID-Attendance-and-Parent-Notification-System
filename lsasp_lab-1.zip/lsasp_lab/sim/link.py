"""Simulated network between terminal and cloud (virtual-clock aware)."""
from lsasp.errors import TransportError


class SimTransport:
    def __init__(self, validator, clock):
        self.validator, self.clock = validator, clock
        self.outages: list[tuple[int, int]] = []     # [start_ms, end_ms)
        self.drop_next_acks = 0                      # process request but lose the response
        self.sent = 0

    def add_outage(self, start_ms: int, end_ms: int) -> None:
        self.outages.append((start_ms, end_ms))

    def _down(self, now: int) -> bool:
        return any(a <= now < b for a, b in self.outages)

    def send(self, batch: dict) -> dict:
        now = self.clock.now_ms()
        if self._down(now):
            raise TransportError("outage")
        self.sent += 1
        resp = self.validator.handle_batch(batch, now)
        if self.drop_next_acks > 0:
            self.drop_next_acks -= 1
            raise TransportError("ack lost")
        return resp
