# Results (laboratory, synthetic data -- not school data, not Raspberry Pi)

Trials per attack: 1000. Cell = attacker successes / trials. Lower is better.

## Attacks

| Attack | v1 | v2 |
|---|---|---|
| A1 replay of an accepted batch (30 s later) | 0/1000 | 0/1000 |
| A2 replay of an accepted batch (10 min later) | 0/1000 | 0/1000 |
| A3 replay after cloud cold start (30 s later) | 1000/1000 | 0/1000 |
| A4 tamper Status (late -> on_time), hash recomputed | 1000/1000 | 0/1000 |
| A5 tamper Terminal_ID (T1 -> T2), hash recomputed | 1000/1000 | 0/1000 |
| A6 tamper Student_ID, hash recomputed | 0/1000 | 0/1000 |
| A7 tamper event time, hash recomputed | 0/1000 | 0/1000 |
| A8 inject forged record without the key | 0/1000 | 0/1000 |
| A9 random bit-flip in transit | 0/1000 | 0/1000 |
| A10 refresh stale batch (forge T_tx) | n/a | 0/1000 |
| A11 forge for another terminal with an extracted key | 1000/1000 | 0/1000 |
| A12 drop a record from a batch in transit | 1000/1000 | 0/1000 |
| A13 malformed or fuzzed batch crashes the validator | 0/1000 | 0/1000 |

## Legitimate record delayed in local buffer (accepted?)

| Delay | v1 | v2 |
|---|---|---|
| 1 min | True | True |
| 4 min | True | True |
| 6 min | False | True |
| 10 min | False | True |
| 30 min | False | True |
| 60 min | False | True |
| 240 min | False | True |
| 1500 min | False | False |

## Batch poisoning (legit records accepted)

| Case | v1 | v2 |
|---|---|---|
| 0 corrupted of 50 | 50/50 | 50/50 |
| 1 corrupted of 50 | 0/49 | 49/49 |
| 2 corrupted of 50 | 0/48 | 48/48 |
| 5 corrupted of 50 | 0/45 | 45/45 |

## Terminal clock offset (accepted? accepted != correct)

| Offset | v1 | v2 |
|---|---|---|
| -24 h | False | True |
| -1 h | False | True |
| -4 min | True | True |
| 0 | True | True |
| +4 min | True | False |
| +1 h | False | False |
| +24 h | False | False |

## System scenarios (simulated clock/link)

**S1 normal day: 150 students, 300 events**

| | recorded | acknowledged_by_terminal | pending_at_end | quarantined | stored_in_cloud | duplicates_in_cloud | latency_p50_s | latency_max_s |
|---|---|---|---|---|---|---|---|---|
| LSASP v1 | 300 | 300 | 0 | 0 | 300 | 0 | 147.6 | 299.9 |
| LSASP v2 | 300 | 300 | 0 | 0 | 300 | 0 | 147.6 | 299.9 |

**S2 one-hour outage, 300 buffered events**

| | recorded | acknowledged_by_terminal | pending_at_end | quarantined | stored_in_cloud | duplicates_in_cloud | latency_p50_s | latency_max_s |
|---|---|---|---|---|---|---|---|---|
| LSASP v1 | 300 | 0 | 300 | 0 | 0 | 0 | None | None |
| LSASP v2 | 300 | 300 | 0 | 0 | 300 | 0 | 2072.8 | 3771.2 |

**S3 first 3 acknowledgments lost, 100 events**

| | recorded | acknowledged_by_terminal | pending_at_end | quarantined | stored_in_cloud | duplicates_in_cloud | latency_p50_s | latency_max_s |
|---|---|---|---|---|---|---|---|---|
| LSASP v1 | 100 | 0 | 100 | 0 | 30 | 0 | 135.3 | 285.3 |
| LSASP v2 | 100 | 100 | 0 | 0 | 100 | 0 | 124.0 | 293.0 |

**S4 one corrupted record at the head of the queue, 100 events**

| | recorded | acknowledged_by_terminal | pending_at_end | quarantined | stored_in_cloud | duplicates_in_cloud | latency_p50_s | latency_max_s |
|---|---|---|---|---|---|---|---|---|
| LSASP v1 | 100 | 0 | 100 | 0 | 0 | 0 | None | None |
| LSASP v2 | 100 | 99 | 0 | 1 | 99 | 0 | 139.9 | 294.9 |

**S5 cloud cold start, then replay of captured batches**

| | before_replay | after_replay | duplicates_in_cloud |
|---|---|---|---|
| LSASP v1 | 50 | 79 | 29 |
| LSASP v2 | 50 | 50 | 0 |


## Ablation: build-up (L0 -> v2)

| Config | attacks succeeded (of 11) | delay 6 min | delay 24 h | poison 1/50 legit accepted | outage 1 h delivered | lost-ack pending+quarantined (of 100) | replay dups after restart |
|---|---|---|---|---|---|---|---|
| L0 = v1 (as in the manuscript) | 5 (+1 n/a) | False | False | 0/49 | 0/300 | 100+0 | 29 |
| L1 = L0 + HMAC-SHA256 over all fields | 3 (+1 n/a) | False | False | 0/49 | 0/300 | 100+0 | 29 |
| L2 = L1 + T_event/T_tx + batch HMAC | 2 | True | False | 0/49 | 300/300 | 0+0 | 50 |
| L3 = L2 + per-record validation | 2 | True | False | 49/49 | 300/300 | 0+37 | 50 |
| L4 = L3 + persistent nonce index | 1 | True | False | 49/49 | 300/300 | 0+37 | 0 |
| L5 = L4 + idempotent acknowledgment | 1 | True | False | 49/49 | 300/300 | 0+0 | 0 |
| L6 = L5 + per-terminal keys (= v2) | 0 | True | False | 49/49 | 300/300 | 0+0 | 0 |

## Ablation: leave-one-out

| Config | attacks succeeded (of 11) | delay 6 min | delay 24 h | poison 1/50 legit accepted | outage 1 h delivered | lost-ack pending+quarantined (of 100) | replay dups after restart |
|---|---|---|---|---|---|---|---|
| v2 without HMAC (v1 token + unkeyed hash) | 3 | True | False | 49/49 | 300/300 | 0+0 | 0 |
| v2 without T_event/T_tx separation | 1 (+1 n/a) | False | False | 49/49 | 0/300 | 34+0 | 0 |
| v2 without per-record validation | 0 | True | False | 0/49 | 300/300 | 0+0 | 0 |
| v2 without persistent nonce index | 1 | True | False | 49/49 | 300/300 | 0+0 | 50 |
| v2 without idempotent acknowledgment | 0 | True | False | 49/49 | 300/300 | 0+37 | 0 |
| v2 without per-terminal keys | 1 | True | False | 49/49 | 300/300 | 0+0 | 0 |
| v2 (all components) | 0 | True | False | 49/49 | 300/300 | 0+0 | 0 |

## 50 simulated school days, 150 virtual students (10 seeds per cell; synthetic workload)

Outage days = days on which one random outage occurred (30% of outages 1-4 min, 70% 10-120 min). Mean (min-max) over seeds.

| Config | outage days | events | stored in cloud | delivered % | still pending | e-mails queued->sent | latency p95 s (max of max) |
|---|---|---|---|---|---|---|---|
| v1@p=0.0 | 0.0 | 14333 | 14333 | 100.0 (100.0-100.0) | 0 | 14333 | 285 (300) |
| v1-24h@p=0.0 | 0.0 | 14333 | 14333 | 100.0 (100.0-100.0) | 0 | 14333 | 285 (300) |
| v2@p=0.0 | 0.0 | 14333 | 14333 | 100.0 (100.0-100.0) | 0 | 14333 | 285 (300) |
| v1@p=0.05 | 2.9 | 14317 | 7196 | 50.3 (6.2-100.0) | 7120 | 7196 | 284 (300) |
| v1-24h@p=0.05 | 2.9 | 14317 | 14317 | 100.0 (100.0-100.0) | 0 | 14317 | 286 (4708) |
| v2@p=0.05 | 2.9 | 14317 | 14317 | 100.0 (100.0-100.0) | 0 | 14317 | 286 (4708) |
| v1@p=0.1 | 4.9 | 14326 | 6978 | 48.7 (2.5-100.0) | 7348 | 6978 | 285 (300) |
| v1-24h@p=0.1 | 4.9 | 14326 | 14326 | 100.0 (100.0-100.0) | 0 | 14326 | 287 (7125) |
| v2@p=0.1 | 4.9 | 14326 | 14326 | 100.0 (100.0-100.0) | 0 | 14326 | 287 (7125) |
| v1@p=0.3 | 16.3 | 14335 | 2837 | 19.8 (1.6-68.9) | 11498 | 2837 | 284 (300) |
| v1-24h@p=0.3 | 16.3 | 14335 | 14335 | 100.0 (100.0-100.0) | 0 | 14335 | 373 (7322) |
| v2@p=0.3 | 16.3 | 14335 | 14335 | 100.0 (100.0-100.0) | 0 | 14335 | 373 (7322) |

## Sensitivity of the v1 baseline to its freshness window

| Config | attacks succeeded | delay accepted 6 min / 1 h / 4 h / 25 h | 1-h outage stored | replay after restart accepted at 30 s / 10 min / 2 h / 25 h | corrupted 1/50: legit accepted |
|---|---|---|---|---|---|
| v1, freshness 5 min (as specified) | 5 | False / False / False / False | 0/300 | True / False / False / False | 0/49 |
| v1, freshness 1 h | 5 | True / True / False / False | 0/300 | True / True / False / False | 0/49 |
| v1, freshness 24 h | 5 | True / True / True / False | 300/300 | True / True / True / False | 0/49 |
| v2 | 0 | True / True / True / False | 300/300 | False / False / False / False | 49/49 |

## Micro-benchmarks (this machine)

```
{"cpu": "Intel(R) Xeon(R) Processor @ 2.10GHz", "cores": 2, "python": "3.13.16", "sqlite": "3.45.1", "os": "Linux-6.18.44-fc-v114-x86_64-with-glibc2.39"}
```
| Operation | mean us | p50 | p95 | p99 |
|---|---|---|---|---|
| sha256_over_record | 0.53 | 0.5 | 0.53 | 0.85 |
| hmac_sha256_over_record | 1.86 | 1.79 | 1.88 | 3.03 |
| nonce_generation_16B | 0.56 | 0.52 | 0.66 | 0.86 |
| make_packet_v1 | 2.4 | 2.29 | 2.57 | 4.4 |
| make_packet_v2 | 7.58 | 7.16 | 9.62 | 26.43 |
| validate_batch50_v1 | 318.7 | 276.6 | 485.8 | 708.6 |
| validate_batch50_v2 | 1289.2 | 1388.3 | 1864.7 | 2552.7 |
| sqlite_insert_commit_sync_FULL | 255.36 | 226.76 | 437.46 | 766.04 |
| sqlite_insert_commit_sync_NORMAL | 27.22 | 12.27 | 42.08 | 67.77 |
