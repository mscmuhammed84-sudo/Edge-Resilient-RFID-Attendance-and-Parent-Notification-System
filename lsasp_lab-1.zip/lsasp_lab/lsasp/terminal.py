import json, pathlib, sqlite3
from .common import new_nonce, classify

SCHEMA = (pathlib.Path(__file__).parent / "schema.sql").read_text()

def backoff_s(attempts, base=30, cap=300):
    """Exponential back-off schedule used between failed uploads."""
    return min(base * 2 ** attempts, cap)

class Terminal:
    def __init__(self, proto, terminal_id="T1", rng=None, batch_size=100):
        self.p, self.tid, self.rng, self.batch_size = proto, terminal_id, rng, batch_size
        self.db = sqlite3.connect(":memory:")
        self.db.executescript(SCHEMA)
        self.fail_count = 0

    def scan(self, student_id, t_event_ms, status=None):
        status = status or classify(t_event_ms)
        nonce = new_nonce(self.rng)
        auth = self.p.build(student_id, t_event_ms, nonce, status, self.tid)
        self.db.execute("INSERT INTO events (student_id,t_event,nonce,status,terminal_id,auth) VALUES (?,?,?,?,?,?)",
                        (student_id, t_event_ms, nonce, status, self.tid, json.dumps(auth)))
        self.db.commit()

    def pending(self):
        return self.db.execute("SELECT COUNT(*) FROM events WHERE synced=0").fetchone()[0]
    def count(self, synced):
        return self.db.execute("SELECT COUNT(*) FROM events WHERE synced=?", (synced,)).fetchone()[0]

    def _batch_records(self):
        rows = self.db.execute("SELECT id,student_id,t_event,nonce,status,terminal_id,auth FROM events "
                               "WHERE synced=0 ORDER BY id LIMIT ?", (self.batch_size,)).fetchall()
        return [dict(id=i, student_id=s, t_event=t, nonce=n, status=st, terminal_id=tid, **json.loads(a))
                for i, s, t, n, st, tid, a in rows]

    def sync(self, send, now_ms):
        """One synchronization cycle. send(batch) -> response dict, or raises ConnectionError."""
        recs = self._batch_records()
        if not recs: return {"sent": 0}
        batch = self.p.make_batch(self.tid, recs, now_ms)
        try:
            resp = send(batch)
        except ConnectionError:
            self.fail_count += 1
            self.db.execute("UPDATE events SET attempts=attempts+1 WHERE synced=0"); self.db.commit()
            return {"sent": len(recs), "error": "network", "retry_in_s": backoff_s(self.fail_count)}
        self.fail_count = 0
        for rid in resp.get("accepted", []):
            self.db.execute("UPDATE events SET synced=1, synced_at=? WHERE id=?", (now_ms, rid))
        for rid in resp.get("quarantined", []):
            self.db.execute("UPDATE events SET synced=2, synced_at=? WHERE id=?", (now_ms, rid))
        if resp.get("whole_batch_rejected"):
            self.db.execute("UPDATE events SET attempts=attempts+1 WHERE synced=0")
        self.db.commit()
        return {"sent": len(recs), **resp}
