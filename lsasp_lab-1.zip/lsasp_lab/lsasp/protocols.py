"""Three record-authentication schemes.
none : no authentication (baseline)
v1   : as in the manuscript - Token=SHA256(sid|ts|nonce|key), Hash=SHA256(Token|status|tid),
       freshness on the record timestamp, whole batch rejected on any failure
v2   : HMAC-SHA256 over all fields, separate T_event / T_tx, batch HMAC, per-record validation
"""
import hmac
from .common import sha256, canon

class NoAuth:
    name = "none"
    def __init__(self, key=b""): pass
    def build(self, sid, t_event, nonce, status, tid): return {}
    def make_batch(self, tid, records, now_ms): return {"terminal_id": tid, "records": records}

class V1:
    name = "v1"
    def __init__(self, key): self.key = key
    def token(self, sid, ts, nonce):
        return sha256(b"|".join([str(sid).encode(), str(ts).encode(), nonce.encode(), self.key])).hex()
    def hash(self, token, status, tid):
        return sha256(b"|".join([token.encode(), status.encode(), tid.encode()])).hex()
    def build(self, sid, t_event, nonce, status, tid):
        t = self.token(sid, t_event, nonce)
        return {"token": t, "hash": self.hash(t, status, tid)}
    def make_batch(self, tid, records, now_ms): return {"terminal_id": tid, "records": records}

class V2:
    name = "v2"
    def __init__(self, key): self.key = key
    def tag(self, sid, t_event, nonce, status, tid):
        return hmac.new(self.key, canon(sid, t_event, nonce, status, tid), "sha256").hexdigest()
    def build(self, sid, t_event, nonce, status, tid):
        return {"tag": self.tag(sid, t_event, nonce, status, tid)}
    def batch_tag(self, tid, t_tx, tags):
        return hmac.new(self.key, canon(tid, t_tx, *tags), "sha256").hexdigest()
    def make_batch(self, tid, records, now_ms):
        tags = [r["tag"] for r in records]
        return {"terminal_id": tid, "t_tx": now_ms, "records": records,
                "batch_tag": self.batch_tag(tid, now_ms, tags)}

PROTOCOLS = {"none": NoAuth, "v1": V1, "v2": V2}
