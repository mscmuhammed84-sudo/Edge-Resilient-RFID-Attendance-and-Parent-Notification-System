import hashlib, os

FRESH_MS = 5 * 60 * 1000            # freshness window (5 min), as in the manuscript
SKEW_MS = 60 * 1000                 # tolerated clock skew into the future (lab choice)
BUFFER_WINDOW_MS = 24 * 3600 * 1000 # v2: maximum buffering window (lab choice)

def sha256(b: bytes) -> bytes:
    return hashlib.sha256(b).digest()

def new_nonce(rng=None) -> str:
    """128-bit random nonce, hex encoded."""
    return (rng.randbytes(16) if rng is not None else os.urandom(16)).hex()

def canon(*fields) -> bytes:
    """Unambiguous encoding: 2-byte length prefix + bytes for every field."""
    out = b""
    for f in fields:
        if not isinstance(f, bytes):
            f = str(f).encode()
        out += len(f).to_bytes(2, "big") + f
    return out

# Example attendance windows (minutes after midnight, UTC). Lab defaults, not school parameters.
DEFAULT_RULES = dict(t_start=7 * 60, t_grace=15, arrival_end=8 * 60 + 30,
                     departure_start=12 * 60 + 30, departure_end=14 * 60)

def classify(t_ms: int, rules=DEFAULT_RULES) -> str:
    m = (t_ms // 60000) % 1440
    if rules["t_start"] <= m <= rules["t_start"] + rules["t_grace"]:
        return "on_time"
    if rules["t_start"] + rules["t_grace"] < m <= rules["arrival_end"]:
        return "late"
    if rules["departure_start"] <= m <= rules["departure_end"]:
        return "departure"
    return "invalid_time"
