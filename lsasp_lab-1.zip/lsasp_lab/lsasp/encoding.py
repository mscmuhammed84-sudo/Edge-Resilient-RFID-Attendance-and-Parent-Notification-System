"""Unambiguous (length-prefixed) encoding used by LSASP v2 so that field
boundaries cannot be shifted."""


def lp(*fields: bytes) -> bytes:
    out = bytearray()
    for f in fields:
        out += len(f).to_bytes(4, "big")
        out += f
    return bytes(out)


def u64(x: int) -> bytes:
    return int(x).to_bytes(8, "big")


def u32(x: int) -> bytes:
    return int(x).to_bytes(4, "big")
