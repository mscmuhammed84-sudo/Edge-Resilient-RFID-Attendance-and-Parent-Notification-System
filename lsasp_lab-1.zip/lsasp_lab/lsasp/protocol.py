"""LSASP protocol library.

One implementation, switchable by `Cfg`, so that the protocol described in the
manuscript ("v1") and the proposed improved protocol ("v2") share all code except
the behaviours under test. This is what makes the ablation experiment fair.

v1 (as described in the manuscript; ASSUMPTIONS are listed in README.md)
    token = SHA-256(Student_ID || Timestamp || Nonce || Secret_Key)
    hash  = SHA-256(token || Status || Terminal_ID)           (unkeyed)
    cloud: freshness on Timestamp (<= 5 min), nonce cache (short-term, in memory),
           recompute token and hash, reject the WHOLE batch if any record fails.

v2 (proposed, NOT part of the field study)
    token = HMAC-SHA256(K_terminal, lp(version, Terminal_ID, Student_ID, T_event,
                                       Nonce, Status))
    batch carries T_tx and a batch HMAC over (Terminal_ID, batch_id, T_tx, tokens)
    cloud: freshness on T_tx; T_event must lie in [T_tx - max_buffer, T_tx + skew];
           per-record validation; persistent nonce index; idempotent acknowledgment
           for duplicates carrying the identical token; per-terminal keys.
"""
from __future__ import annotations

import hashlib
import hmac
import os
import sqlite3
from dataclasses import dataclass, replace
from typing import Callable, Optional

from .encoding import lp, u32, u64

STATUSES = ("on_time", "late", "departure")


@dataclass(frozen=True)
class Cfg:
    name: str
    mac: str = "v1"                   # 'v1' (SHA-256 key-suffix + unkeyed hash) | 'hmac'
    time_model: str = "single"        # 'single' (one timestamp) | 'event_tx'
    per_record: bool = False          # False: reject whole batch on any failure
    nonce_store: str = "memory_ttl"   # 'memory_ttl' | 'persistent'
    idempotent: bool = False          # ack duplicates that carry the identical token
    per_terminal_keys: bool = False   # derive K_terminal from a master key
    freshness_s: int = 300
    one_sided_freshness: bool = False  # v1 variant: only (now - ts) <= freshness
    max_buffer_s: int = 24 * 3600
    skew_s: int = 60


V1 = Cfg("v1")
V2 = Cfg("v2", mac="hmac", time_model="event_tx", per_record=True,
         nonce_store="persistent", idempotent=True, per_terminal_keys=True)


# ----------------------------------------------------------------------------- keys
def terminal_key(cfg: Cfg, master: bytes, terminal_id: str) -> bytes:
    if cfg.per_terminal_keys:
        return hmac.new(master, lp(b"LSASP2-KEY", terminal_id.encode()), hashlib.sha256).digest()
    return master


def new_nonce() -> str:
    return os.urandom(16).hex()  # 128-bit


# ------------------------------------------------------------------- packet building
def _v1_token(sid: str, ts: int, nonce: str, key: bytes) -> str:
    return hashlib.sha256(f"{sid}{ts}{nonce}".encode() + key).hexdigest()


def _v1_hash(token: str, status: str, tid: str) -> str:
    return hashlib.sha256(f"{token}{status}{tid}".encode()).hexdigest()


def _rec_enc(tid: str, sid: str, t_event: int, nonce: str, status: str) -> bytes:
    return lp(b"LSASP2-REC", tid.encode(), sid.encode(), u64(t_event),
              bytes.fromhex(nonce), status.encode())


def make_packet(cfg: Cfg, key: bytes, student_id: str, t_event_ms: int, status: str,
                terminal_id: str, nonce: Optional[str] = None) -> dict:
    nonce = nonce or new_nonce()
    if cfg.mac == "v1":
        token = _v1_token(student_id, t_event_ms, nonce, key)
        h = _v1_hash(token, status, terminal_id)
    else:
        enc = _rec_enc(terminal_id, student_id, t_event_ms, nonce, status)
        token = hmac.new(key, enc, hashlib.sha256).hexdigest()
        h = hashlib.sha256(enc + bytes.fromhex(token)).hexdigest()  # corruption check only
    return {"student_id": student_id, "t_event": t_event_ms, "nonce": nonce,
            "status": status, "terminal_id": terminal_id, "token": token, "hash": h}


def _batch_mac(key: bytes, terminal_id: str, batch_id: str, t_tx: int, tokens: list[str]) -> str:
    enc = lp(b"LSASP2-BATCH", terminal_id.encode(), batch_id.encode(), u64(t_tx),
             u32(len(tokens)), *[bytes.fromhex(t) for t in tokens])
    return hmac.new(key, enc, hashlib.sha256).hexdigest()


def make_batch(cfg: Cfg, key: bytes, terminal_id: str, packets: list[dict],
               t_tx_ms: int, batch_id: str) -> dict:
    batch = {"terminal_id": terminal_id, "batch_id": batch_id, "records": packets}
    if cfg.time_model == "event_tx":
        batch["t_tx"] = t_tx_ms
        if cfg.mac == "hmac":
            batch["batch_mac"] = _batch_mac(key, terminal_id, batch_id, t_tx_ms,
                                            [p["token"] for p in packets])
    return batch


# ------------------------------------------------------------------- nonce stores
class MemoryTTLStore:
    """Short-term in-memory nonce cache (lost on restart)."""

    def __init__(self, ttl_s: int):
        self.ttl_ms = ttl_s * 1000
        self._d: dict[tuple[str, str], tuple[str, int]] = {}

    def seen(self, terminal_id: str, nonce: str, now_ms: int) -> Optional[str]:
        v = self._d.get((terminal_id, nonce))
        if v is None:
            return None
        if now_ms - v[1] > self.ttl_ms:
            del self._d[(terminal_id, nonce)]
            return None
        return v[0]

    def add(self, terminal_id: str, nonce: str, token: str, now_ms: int) -> None:
        self._d[(terminal_id, nonce)] = (token, now_ms)

    def restart(self) -> None:
        self._d.clear()


class SQLiteNonceStore:
    """Persistent nonce index; survives restarts."""

    def __init__(self, path: str = ":memory:", retention_s: int = 2 * 24 * 3600):
        self.conn = sqlite3.connect(path, check_same_thread=False)  # callers serialise access (server holds a lock)
        self.retention_ms = retention_s * 1000
        self.conn.execute("""CREATE TABLE IF NOT EXISTS nonces(
            terminal_id TEXT NOT NULL, nonce TEXT NOT NULL, token TEXT NOT NULL,
            first_seen_ms INTEGER NOT NULL, PRIMARY KEY(terminal_id, nonce))""")
        self.conn.commit()

    def seen(self, terminal_id: str, nonce: str, now_ms: int) -> Optional[str]:
        r = self.conn.execute("SELECT token FROM nonces WHERE terminal_id=? AND nonce=?",
                              (terminal_id, nonce)).fetchone()
        return r[0] if r else None

    def add(self, terminal_id: str, nonce: str, token: str, now_ms: int) -> None:
        self.conn.execute("INSERT OR IGNORE INTO nonces VALUES(?,?,?,?)",
                          (terminal_id, nonce, token, now_ms))
        self.conn.commit()

    def prune(self, now_ms: int) -> int:
        cur = self.conn.execute("DELETE FROM nonces WHERE first_seen_ms < ?",
                                (now_ms - self.retention_ms,))
        self.conn.commit()
        return cur.rowcount

    def restart(self) -> None:  # persistent: nothing is lost
        pass


# --------------------------------------------------------------------- validator
PERMANENT = {"malformed", "bad_mac", "replay", "unknown_terminal", "terminal_mismatch",
             "event_time_out_of_window"}


class Validator:
    """Cloud-side validation service (the logic that would run in the HTTPS endpoint
    or cloud function)."""

    def __init__(self, cfg: Cfg, master_key: bytes, terminals: Optional[set[str]] = None,
                 nonce_store=None, on_accept: Optional[Callable[[dict], None]] = None):
        self.cfg = cfg
        self.master = master_key
        self.terminals = terminals            # None => accept any terminal id
        self.store = nonce_store or (SQLiteNonceStore() if cfg.nonce_store == "persistent"
                                     else MemoryTTLStore(cfg.freshness_s))
        self.on_accept = on_accept
        self.accepted_records: list[dict] = []

    # -- helpers -------------------------------------------------------------
    def restart(self) -> None:
        """Simulate a cold start of the cloud function / server."""
        self.store.restart()

    def _key_for(self, tid: str) -> Optional[bytes]:
        if self.cfg.per_terminal_keys and self.terminals is not None and tid not in self.terminals:
            return None
        return terminal_key(self.cfg, self.master, tid)

    @staticmethod
    def _wellformed(r) -> bool:
        try:
            return (isinstance(r["student_id"], str) and isinstance(r["t_event"], int)
                    and not isinstance(r["t_event"], bool)
                    and isinstance(r["nonce"], str) and len(r["nonce"]) == 32
                    and all(c in "0123456789abcdef" for c in r["nonce"])
                    and r["status"] in STATUSES and isinstance(r["terminal_id"], str)
                    and isinstance(r["token"], str) and isinstance(r["hash"], str))
        except (KeyError, TypeError):
            return False

    def _check_mac(self, r: dict, key: bytes) -> bool:
        cfg = self.cfg
        try:
            if cfg.mac == "v1":
                tok = _v1_token(r["student_id"], r["t_event"], r["nonce"], key)
                h = _v1_hash(r["token"], r["status"], r["terminal_id"])
                return (hmac.compare_digest(tok, r["token"]) and
                        hmac.compare_digest(h, r["hash"]))
            enc = _rec_enc(r["terminal_id"], r["student_id"], r["t_event"], r["nonce"], r["status"])
            tok = hmac.new(key, enc, hashlib.sha256).hexdigest()
            if not hmac.compare_digest(tok, r["token"]):
                return False
            h = hashlib.sha256(enc + bytes.fromhex(tok)).hexdigest()
            return hmac.compare_digest(h, r["hash"])
        except (ValueError, TypeError):
            return False

    def _check_record(self, r: dict, batch: dict, now_ms: int, batch_nonces: set) -> tuple[str, str]:
        cfg = self.cfg
        if not self._wellformed(r):
            return "rejected", "malformed"
        tid = r["terminal_id"]
        if cfg.per_terminal_keys:
            if tid != batch.get("terminal_id"):
                return "rejected", "terminal_mismatch"
        key = self._key_for(tid)
        if key is None:
            return "rejected", "unknown_terminal"
        # time
        if cfg.time_model == "single":
            age_s = (now_ms - r["t_event"]) / 1000
            ok = age_s <= cfg.freshness_s if cfg.one_sided_freshness else abs(age_s) <= cfg.freshness_s
            if not ok:
                return "rejected", "stale"
        else:
            t_tx = batch["t_tx"]
            if r["t_event"] > t_tx + cfg.skew_s * 1000 or t_tx - r["t_event"] > cfg.max_buffer_s * 1000:
                return "rejected", "event_time_out_of_window"
        # authenticity first (so duplicates can be acknowledged safely)
        if not self._check_mac(r, key):
            return "rejected", "bad_mac"
        # replay / duplicate
        prev = self.store.seen(tid, r["nonce"], now_ms)
        if prev is not None or (tid, r["nonce"]) in batch_nonces:
            if cfg.idempotent and prev == r["token"]:
                return "duplicate", "already_accepted"
            return "rejected", "replay"
        batch_nonces.add((tid, r["nonce"]))
        return "accepted", ""

    # -- public API ------------------------------------------------------------
    def handle_batch(self, batch: dict, now_ms: int) -> dict:
        cfg = self.cfg
        recs = batch.get("records") if isinstance(batch, dict) else None
        if not isinstance(recs, list):
            return {"ok": False, "batch_error": "malformed", "results": []}
        if cfg.time_model == "event_tx":
            t_tx = batch.get("t_tx")
            if not isinstance(t_tx, int) or isinstance(t_tx, bool):
                return {"ok": False, "batch_error": "malformed", "results": []}
            if abs(now_ms - t_tx) > cfg.freshness_s * 1000:
                return {"ok": False, "batch_error": "stale_batch", "results": []}
            if cfg.mac == "hmac":
                tid = batch.get("terminal_id")
                key = self._key_for(tid) if isinstance(tid, str) else None
                try:
                    exp = _batch_mac(key, tid, str(batch.get("batch_id")), t_tx,
                                     [r["token"] for r in recs]) if key else None
                except (ValueError, KeyError, TypeError):
                    exp = None
                if exp is None or not hmac.compare_digest(exp, str(batch.get("batch_mac"))):
                    return {"ok": False, "batch_error": "bad_batch_mac", "results": []}
        seen: set = set()
        checks = [self._check_record(r, batch, now_ms, seen) if isinstance(r, dict)
                  else ("rejected", "malformed") for r in recs]
        results = []
        if not cfg.per_record and any(s == "rejected" for s, _ in checks):
            for r, (s, why) in zip(recs, checks):
                results.append({"nonce": r.get("nonce") if isinstance(r, dict) else None,
                                "status": "rejected",
                                "reason": why if s == "rejected" else "batch_rejected",
                                "permanent": False})
            return {"ok": False, "batch_error": None, "results": results}
        for r, (s, why) in zip(recs, checks):
            nonce = r.get("nonce") if isinstance(r, dict) else None
            if s == "accepted":
                self.store.add(r["terminal_id"], r["nonce"], r["token"], now_ms)
                self.accepted_records.append(dict(r, accepted_ms=now_ms))
                if self.on_accept:
                    self.on_accept(r)
            results.append({"nonce": nonce, "status": s, "reason": why,
                            "permanent": s == "rejected" and why in PERMANENT})
        return {"ok": True, "batch_error": None, "results": results}


def variant(cfg: Cfg, **kw) -> Cfg:
    return replace(cfg, **kw)
