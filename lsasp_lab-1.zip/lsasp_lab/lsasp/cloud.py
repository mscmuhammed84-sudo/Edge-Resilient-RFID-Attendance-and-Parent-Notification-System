import hmac, json, sqlite3, pathlib
from .common import FRESH_MS, SKEW_MS, BUFFER_WINDOW_MS
from .protocols import V1, V2

SCHEMA = (pathlib.Path(__file__).parent / "schema.sql").read_text()
FIELDS = ("student_id", "t_event", "nonce", "status", "terminal_id")

class CloudBase:
    def __init__(self, proto):
        self.p = proto
        self.db = sqlite3.connect(":memory:")
        self.db.executescript(SCHEMA)

    # -------- helpers --------
    def _well_formed(self, r, extra=()):
        return all(k in r for k in FIELDS + tuple(extra))
    def _commit(self, tid, r, now_ms):
        self.db.execute("INSERT INTO nonces VALUES (?,?,?)", (tid, r["nonce"], now_ms))
        self.db.execute("INSERT INTO accepted VALUES (?,?,?,?,?,?)",
                        (tid, r["nonce"], r["student_id"], r["t_event"], r["status"], now_ms))
    def _seen(self, tid, nonce):
        return self.db.execute("SELECT 1 FROM nonces WHERE terminal_id=? AND nonce=?", (tid, nonce)).fetchone() is not None
    def _log(self, tid, r, reason, now_ms):
        self.db.execute("INSERT INTO quarantine (terminal_id,nonce,reason,received_ms,raw) VALUES (?,?,?,?,?)",
                        (tid, r.get("nonce"), reason, now_ms, json.dumps(r, sort_keys=True)))
    def accepted_count(self):
        return self.db.execute("SELECT COUNT(*) FROM accepted").fetchone()[0]

class CloudNone(CloudBase):
    """No authentication: accepts any well-formed record (baseline)."""
    def receive(self, batch, now_ms):
        tid = batch.get("terminal_id"); acc, quar = [], []
        for r in batch.get("records", []):
            if self._well_formed(r):
                self.db.execute("INSERT OR IGNORE INTO accepted VALUES (?,?,?,?,?,?)",
                    (tid, r["nonce"], r["student_id"], r["t_event"], r["status"], now_ms))
                acc.append(r["id"])
            else:
                quar.append(r.get("id"))
        return {"accepted": acc, "quarantined": quar, "whole_batch_rejected": False, "reasons": {}}

class CloudV1(CloudBase):
    """As in the manuscript: any failing check rejects the whole batch."""
    def _prune(self, now_ms):
        self.db.execute("DELETE FROM nonces WHERE seen_ms < ?", (now_ms - FRESH_MS - SKEW_MS,))
    def receive(self, batch, now_ms):
        self._prune(now_ms)
        tid = batch.get("terminal_id"); recs = batch.get("records", []); reasons = {}; seen = set()
        for r in recs:
            rid = r.get("id")
            if not self._well_formed(r, ("token", "hash")): reasons[rid] = "missing_field"; continue
            if now_ms - r["t_event"] > FRESH_MS or r["t_event"] - now_ms > SKEW_MS:
                reasons[rid] = "stale_timestamp"; continue
            if self._seen(tid, r["nonce"]) or r["nonce"] in seen:
                reasons[rid] = "nonce_replay"; continue
            seen.add(r["nonce"])
            tok = self.p.token(r["student_id"], r["t_event"], r["nonce"])
            if not hmac.compare_digest(tok, str(r["token"])): reasons[rid] = "bad_token"; continue
            if not hmac.compare_digest(self.p.hash(r["token"], r["status"], r["terminal_id"]), str(r["hash"])):
                reasons[rid] = "bad_hash"
        if reasons:
            for r in recs:
                if r.get("id") in reasons: self._log(tid, r, reasons[r["id"]], now_ms)
            return {"accepted": [], "quarantined": [], "whole_batch_rejected": True, "reasons": reasons}
        for r in recs: self._commit(tid, r, now_ms)
        return {"accepted": [r["id"] for r in recs], "quarantined": [], "whole_batch_rejected": False, "reasons": {}}

class CloudV2(CloudBase):
    """HMAC-SHA256, freshness on T_tx, T_event window, per-record validation."""
    def _prune(self, now_ms):
        self.db.execute("DELETE FROM nonces WHERE seen_ms < ?", (now_ms - BUFFER_WINDOW_MS - FRESH_MS,))
    def receive(self, batch, now_ms):
        self._prune(now_ms)
        tid = batch.get("terminal_id"); recs = batch.get("records", [])
        if "t_tx" not in batch or "batch_tag" not in batch or not all("tag" in r for r in recs):
            return {"accepted": [], "quarantined": [], "whole_batch_rejected": True, "reasons": {"*": "missing_field"}}
        if not hmac.compare_digest(self.p.batch_tag(tid, batch["t_tx"], [r["tag"] for r in recs]), str(batch["batch_tag"])):
            return {"accepted": [], "quarantined": [], "whole_batch_rejected": True, "reasons": {"*": "bad_batch_tag"}}
        if abs(now_ms - batch["t_tx"]) > FRESH_MS:
            return {"accepted": [], "quarantined": [], "whole_batch_rejected": True, "reasons": {"*": "stale_batch"}}
        acc, quar, reasons = [], [], {}
        for r in recs:
            rid = r.get("id"); why = None
            if not self._well_formed(r, ("tag",)): why = "missing_field"
            elif r["t_event"] - batch["t_tx"] > SKEW_MS: why = "future_event"
            elif batch["t_tx"] - r["t_event"] > BUFFER_WINDOW_MS: why = "event_too_old"
            elif not hmac.compare_digest(self.p.tag(r["student_id"], r["t_event"], r["nonce"], r["status"], r["terminal_id"]), str(r["tag"])):
                why = "bad_tag"
            elif self._seen(tid, r["nonce"]): why = "nonce_replay"
            if why:
                self._log(tid, r, why, now_ms); quar.append(rid); reasons[rid] = why
            else:
                self._commit(tid, r, now_ms); acc.append(rid)
        return {"accepted": acc, "quarantined": quar, "whole_batch_rejected": False, "reasons": reasons}

def make_cloud(proto):
    return {"none": CloudNone, "v1": CloudV1, "v2": CloudV2}[proto.name](proto)
