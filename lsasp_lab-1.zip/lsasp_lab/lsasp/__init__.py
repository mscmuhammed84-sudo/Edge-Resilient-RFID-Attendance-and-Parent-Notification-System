"""Laboratory implementation of LSASP (as described in the manuscript) and an improved v2.
NOT field data: used only for protocol-level experiments."""
