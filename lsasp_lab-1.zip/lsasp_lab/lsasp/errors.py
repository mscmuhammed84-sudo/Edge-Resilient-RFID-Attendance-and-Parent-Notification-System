class TransportError(Exception):
    """Network-level failure (outage, timeout, lost response)."""
