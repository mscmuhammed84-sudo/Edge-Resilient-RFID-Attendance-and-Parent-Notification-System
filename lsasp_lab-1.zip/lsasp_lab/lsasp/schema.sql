-- Terminal-side buffer (SQLite)
CREATE TABLE IF NOT EXISTS events (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  student_id  TEXT    NOT NULL,
  t_event     INTEGER NOT NULL,                 -- ms since epoch, terminal clock at scan
  nonce       TEXT    NOT NULL UNIQUE,          -- 128-bit random, hex
  status      TEXT    NOT NULL CHECK (status IN ('on_time','late','departure','invalid_time')),
  terminal_id TEXT    NOT NULL,
  auth        TEXT    NOT NULL,                 -- JSON: protocol-specific token/hash/tag
  synced      INTEGER NOT NULL DEFAULT 0 CHECK (synced IN (0,1,2)), -- 0 pending, 1 accepted, 2 quarantined by cloud
  attempts    INTEGER NOT NULL DEFAULT 0,
  synced_at   INTEGER
);
CREATE INDEX IF NOT EXISTS idx_events_synced ON events (synced, id);

-- Cloud-side stores (SQLite stand-in for the Firebase validation service)
CREATE TABLE IF NOT EXISTS nonces (
  terminal_id TEXT NOT NULL, nonce TEXT NOT NULL, seen_ms INTEGER NOT NULL,
  PRIMARY KEY (terminal_id, nonce)
);
CREATE TABLE IF NOT EXISTS accepted (
  terminal_id TEXT NOT NULL, nonce TEXT NOT NULL, student_id TEXT NOT NULL,
  t_event INTEGER NOT NULL, status TEXT NOT NULL, received_ms INTEGER NOT NULL,
  PRIMARY KEY (terminal_id, nonce)
);
CREATE TABLE IF NOT EXISTS quarantine (
  id INTEGER PRIMARY KEY AUTOINCREMENT, terminal_id TEXT, nonce TEXT,
  reason TEXT NOT NULL, received_ms INTEGER NOT NULL, raw TEXT
);
