"""Clock abstractions. A virtual clock lets tests and simulations run hours of
'time' instantly and deterministically."""
import time
from datetime import datetime, timezone


class SystemClock:
    def now_ms(self) -> int:
        return time.time_ns() // 1_000_000


class VirtualClock:
    def __init__(self, start_ms: int | None = None):
        if start_ms is None:
            # 2026-03-01 05:00 UTC = 08:00 in Baghdad (UTC+3)
            start_ms = int(datetime(2026, 3, 1, 5, 0, tzinfo=timezone.utc).timestamp() * 1000)
        self._ms = start_ms

    def now_ms(self) -> int:
        return self._ms

    def set_ms(self, ms: int) -> None:
        self._ms = ms

    def advance_s(self, seconds: float) -> None:
        self._ms += int(seconds * 1000)
