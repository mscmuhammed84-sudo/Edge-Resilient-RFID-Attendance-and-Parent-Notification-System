"""Minimal HTTPS-ready sync endpoint (stdlib only). Run it BEHIND a TLS-terminating
reverse proxy (nginx/Caddy); it binds to localhost by default."""
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from threading import Lock

MAX_BODY = 1_000_000


def make_server(validator, clock, host: str = "127.0.0.1", port: int = 8080):
    lock = Lock()

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):  # quiet
            pass

        def do_POST(self):
            if self.path != "/sync":
                self.send_error(404); return
            n = int(self.headers.get("Content-Length", "0") or 0)
            if n <= 0 or n > MAX_BODY:
                self.send_error(413); return
            try:
                batch = json.loads(self.rfile.read(n))
            except ValueError:
                self.send_error(400); return
            with lock:
                resp = validator.handle_batch(batch, clock.now_ms())
            data = json.dumps(resp).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

    return ThreadingHTTPServer((host, port), H)
