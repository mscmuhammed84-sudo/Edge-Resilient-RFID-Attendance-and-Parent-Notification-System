"""Parent notification (cloud side). Parent e-mail addresses are held here only.
E-mail is queued and sent by a worker so that slow SMTP never delays acknowledgments."""
import smtplib
from email.message import EmailMessage
from typing import Optional


class RecordingMailer:
    def __init__(self, fail_for=()):
        self.sent: list[dict] = []
        self.fail_for = set(fail_for)

    def send(self, to: str, subject: str, body: str) -> None:
        if to in self.fail_for:
            raise RuntimeError("delivery failed")
        self.sent.append({"to": to, "subject": subject, "body": body})


class SmtpMailer:  # pragma: no cover - needs a real SMTP server
    def __init__(self, host: str, port: int, user: Optional[str], password: Optional[str],
                 sender: str, starttls: bool = True, timeout: int = 20):
        self.host, self.port, self.user, self.password = host, port, user, password
        self.sender, self.starttls, self.timeout = sender, starttls, timeout

    def send(self, to: str, subject: str, body: str) -> None:
        m = EmailMessage()
        m["From"], m["To"], m["Subject"] = self.sender, to, subject
        m.set_content(body)
        with smtplib.SMTP(self.host, self.port, timeout=self.timeout) as s:
            if self.starttls:
                s.starttls()
            if self.user:
                s.login(self.user, self.password)
            s.send_message(m)


class Notifier:
    def __init__(self, parents: dict[str, dict], mailer):
        self.parents, self.mailer = parents, mailer     # student_id -> {"name":..., "email":...}
        self.queue: list[dict] = []
        self.failed: list[dict] = []                    # for administrator review

    def on_accept(self, rec: dict) -> None:
        self.queue.append(rec)

    def flush(self) -> int:
        n = 0
        while self.queue:
            rec = self.queue.pop(0)
            p = self.parents.get(rec["student_id"])
            if not p or not p.get("email"):
                self.failed.append({"record": rec, "error": "no_parent_address"}); continue
            subject = f"Attendance: {p.get('name', rec['student_id'])} - {rec['status']}"
            body = (f"Student {p.get('name', rec['student_id'])} was recorded as {rec['status']} "
                    f"at event time {rec['t_event']} (ms since epoch, UTC).")
            try:
                self.mailer.send(p["email"], subject, body); n += 1
            except Exception as e:  # noqa: BLE001 - any delivery failure goes to the review list
                self.failed.append({"record": rec, "error": str(e)})
        return n
