import os
import random
import tempfile
import unittest

from edge.db import EdgeDB
from edge.sync import SyncManager
from edge.terminal import RecordingFeedback, Terminal
from lsasp.clock import VirtualClock
from lsasp.protocol import V1, V2, Validator, terminal_key
from sim.link import SimTransport

MASTER = b"m" * 32


class Rig:
    def __init__(self, cfg, n_students=20, db_path=":memory:", **sync_kw):
        self.c = VirtualClock()                        # 08:00 local
        self.cfg = cfg
        self.v = Validator(cfg, MASTER, {"T1"})
        self.key = terminal_key(cfg, MASTER, "T1")
        self.db = EdgeDB(db_path)
        for i in range(n_students):
            self.db.authorize(f"c{i}", f"S{i}")
        self.fb = RecordingFeedback()
        self.t = Terminal(self.db, cfg, self.key, "T1", self.c, feedback=self.fb)
        self.tr = SimTransport(self.v, self.c)
        self.sm = SyncManager(self.db, self.tr, self.c, cfg, self.key, "T1", rng=random.Random(1), **sync_kw)

    def scan(self, i): return self.t.handle_scan(f"c{i}")


class TerminalTests(unittest.TestCase):
    def test_invalid_card_debounce_invalid_time(self):
        r = Rig(V2)
        self.assertEqual(r.t.handle_scan("nope")["result"], "invalid_card")
        self.assertEqual(r.scan(1)["result"], "recorded")
        self.assertEqual(r.scan(1)["result"], "debounced")
        r.c.advance_s(31)
        self.assertEqual(r.scan(1)["result"], "recorded")
        r.c.advance_s(5 * 3600)                         # 13:00 -> departure window
        self.assertEqual(r.scan(2)["status"], "departure")
        r.c.advance_s(4 * 3600)                         # 17:00 -> outside
        self.assertEqual(r.scan(3)["result"], "invalid_time")
        self.assertIn(("lcd", "Invalid card"), r.fb.log)

    def test_record_survives_reopen(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "edge.db")
            r = Rig(V2, db_path=p); r.scan(1); r.db.conn.close()
            db2 = EdgeDB(p)
            self.assertEqual(db2.counts()["pending"], 1)

    def test_unique_nonce_constraint(self):
        r = Rig(V2); r.scan(1)
        row = r.db.unsynced(1)[0]
        with self.assertRaises(Exception):
            r.db.insert_record(row)


class SyncTests(unittest.TestCase):
    def fill(self, r, n):
        for k in range(n):
            r.scan(k % 20); r.c.advance_s(31 if k % 20 == 19 else 1.5)

    def test_normal_delivery_both_versions(self):
        for cfg in (V1, V2):
            r = Rig(cfg); self.fill(r, 20)
            self.assertEqual(r.sm.tick(), "ok")
            self.assertEqual(r.db.counts()["acknowledged"], 20)
            self.assertEqual(len(r.v.accepted_records), 20)

    def test_one_hour_outage_v2_delivers_all_v1_delivers_none(self):
        out = {}
        for cfg in (V1, V2):
            r = Rig(cfg)
            r.tr.add_outage(r.c.now_ms(), r.c.now_ms() + 3700 * 1000)
            for k in range(60):
                r.scan(k % 20); r.c.advance_s(60 if k % 20 == 19 else 1)
                r.sm.tick()
            r.c.advance_s(3700)
            for _ in range(40):
                r.sm.tick(); r.c.advance_s(60)
            out[cfg.name] = (r.db.counts(), len(r.v.accepted_records))
        self.assertEqual(out["v2"][0]["acknowledged"], 60)
        self.assertEqual(out["v2"][1], 60)
        self.assertLess(out["v1"][1], 60)               # stale records are rejected by v1

    def test_backoff_grows_and_resets(self):
        r = Rig(V2); r.scan(1)
        r.tr.add_outage(0, 10**15)
        gaps, last = [], None
        for _ in range(8):
            now = r.c.now_ms(); res = r.sm.tick(); self.assertEqual(res, "transport_error")
            gaps.append((r.sm.next_ms - now) / 1000)
            r.c.set_ms(r.sm.next_ms)
        self.assertLess(gaps[0], gaps[2]); self.assertLessEqual(max(gaps), 300 * 1.25 + 1e-6)
        r.tr.outages.clear(); r.c.set_ms(r.sm.next_ms)
        self.assertEqual(r.sm.tick(), "ok")
        self.assertEqual(r.sm.fails, 0)

    def test_lost_ack(self):
        res = {}
        for cfg in (V1, V2):
            r = Rig(cfg); self.fill(r, 5)
            r.tr.drop_next_acks = 1
            self.assertEqual(r.sm.tick(), "transport_error")
            r.c.set_ms(r.sm.next_ms)
            r.sm.tick()
            res[cfg.name] = (r.db.counts()["acknowledged"], len(r.v.accepted_records))
        self.assertEqual(res["v2"], (5, 5))              # idempotent: acknowledged, no duplicates
        self.assertEqual(res["v1"][0], 0)                # terminal never learns the records arrived
        self.assertEqual(res["v1"][1], 5)                # ...although the cloud already stored them

    def test_poison_record(self):
        res = {}
        for cfg in (V1, V2):
            r = Rig(cfg); self.fill(r, 10)
            r.db.conn.execute("UPDATE attendance SET token=? WHERE id=3", ("00" * 32,)); r.db.commit()
            for _ in range(10):
                r.sm.tick(); r.c.set_ms(max(r.c.now_ms(), r.sm.next_ms))
            res[cfg.name] = r.db.counts()
        self.assertEqual(res["v2"]["acknowledged"], 9); self.assertEqual(res["v2"]["quarantined"], 1)
        self.assertEqual(res["v1"]["acknowledged"], 0)   # one bad record blocks everything behind it

    def test_batch_size_and_draining(self):
        r = Rig(V2, batch_size=7); self.fill(r, 20)
        self.assertEqual(r.sm.tick(), "ok")
        self.assertEqual(r.db.counts()["acknowledged"], 20)
        self.assertEqual(r.sm.stats["batches"], 3)


if __name__ == "__main__":
    unittest.main()
