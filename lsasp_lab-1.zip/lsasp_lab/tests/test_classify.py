import unittest
from datetime import datetime, timezone
from edge.classify import TimeWindows, classify


def ms(h, m):  # local (UTC+3) wall-clock time -> epoch ms
    return int(datetime(2026, 3, 1, h - 3, m, tzinfo=timezone.utc).timestamp() * 1000)


class T(unittest.TestCase):
    def test_windows(self):
        w = TimeWindows()
        self.assertEqual(classify(ms(6, 59), w), "invalid_time")
        self.assertEqual(classify(ms(7, 0), w), "on_time")
        self.assertEqual(classify(ms(7, 14), w), "on_time")
        self.assertEqual(classify(ms(7, 15), w), "late")
        self.assertEqual(classify(ms(9, 0), w), "late")
        self.assertEqual(classify(ms(9, 1), w), "invalid_time")
        self.assertEqual(classify(ms(11, 59), w), "invalid_time")
        self.assertEqual(classify(ms(12, 0), w), "departure")
        self.assertEqual(classify(ms(15, 0), w), "departure")
        self.assertEqual(classify(ms(15, 1), w), "invalid_time")

    def test_timezone_matters(self):
        t = ms(10, 0)                       # 10:00 in Baghdad == 07:00 UTC
        self.assertEqual(classify(t, TimeWindows(tz_offset_min=180)), "invalid_time")
        self.assertEqual(classify(t, TimeWindows(tz_offset_min=0)), "on_time")


if __name__ == "__main__":
    unittest.main()
