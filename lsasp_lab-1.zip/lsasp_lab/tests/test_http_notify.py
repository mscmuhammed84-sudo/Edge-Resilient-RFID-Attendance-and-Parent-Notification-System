import threading
import unittest

from cloud.notify import Notifier, RecordingMailer
from cloud.server import make_server
from edge.transport_http import HttpTransport
from lsasp.clock import SystemClock
from lsasp.errors import TransportError
from lsasp.protocol import V2, Validator, make_batch, make_packet, terminal_key

MASTER = b"m" * 32


class HttpTest(unittest.TestCase):
    def test_roundtrip_and_unreachable(self):
        clock = SystemClock()
        v = Validator(V2, MASTER, {"T1"})
        srv = make_server(v, clock, port=0)
        th = threading.Thread(target=srv.serve_forever, daemon=True); th.start()
        try:
            url = f"http://127.0.0.1:{srv.server_address[1]}/sync"
            key = terminal_key(V2, MASTER, "T1")
            p = make_packet(V2, key, "S1", clock.now_ms(), "late", "T1")
            resp = HttpTransport(url).send(make_batch(V2, key, "T1", [p], clock.now_ms(), "b"))
            self.assertTrue(resp["ok"]); self.assertEqual(len(v.accepted_records), 1)
        finally:
            srv.shutdown(); srv.server_close()
        with self.assertRaises(TransportError):
            HttpTransport(url, timeout=1).send({"records": []})


class NotifyTest(unittest.TestCase):
    def test_queue_flush_failures(self):
        m = RecordingMailer(fail_for={"bad@x"})
        n = Notifier({"S1": {"name": "A", "email": "a@x"}, "S2": {"name": "B", "email": "bad@x"},
                      "S3": {"name": "C"}}, m)
        for sid in ("S1", "S2", "S3", "S9"):
            n.on_accept({"student_id": sid, "status": "late", "t_event": 1})
        self.assertEqual(n.flush(), 1)
        self.assertEqual(len(m.sent), 1)
        self.assertEqual(sorted(f["error"] for f in n.failed),
                         ["delivery failed", "no_parent_address", "no_parent_address"])


if __name__ == "__main__":
    unittest.main()
