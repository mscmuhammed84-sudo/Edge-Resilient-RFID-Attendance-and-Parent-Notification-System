import copy
import random
import unittest
from lsasp.clock import VirtualClock
from lsasp.protocol import V1, V2, Validator, make_batch, make_packet, terminal_key, variant

MASTER = b"m" * 32


def setup(cfg, tid="T1"):
    c = VirtualClock()
    v = Validator(cfg, MASTER, {"T1", "T2"})
    key = terminal_key(cfg, MASTER, tid)
    return c, v, key


def one(cfg, c, key, tid="T1", status="late", sid="S1"):
    return make_packet(cfg, key, sid, c.now_ms(), status, tid)


class Basic(unittest.TestCase):
    def test_accept_and_resend(self):
        for cfg in (V1, V2):
            c, v, key = setup(cfg)
            b = make_batch(cfg, key, "T1", [one(cfg, c, key) for _ in range(3)], c.now_ms(), "b")
            r = v.handle_batch(b, c.now_ms())
            self.assertTrue(r["ok"]); self.assertEqual(len(v.accepted_records), 3)

    def test_nonce_is_128_bit_hex(self):
        c, v, key = setup(V2)
        p = one(V2, c, key)
        self.assertEqual(len(bytes.fromhex(p["nonce"])), 16)

    def test_tamper_without_key_v2_rejected(self):
        c, v, key = setup(V2)
        for field, val in (("status", "on_time"), ("terminal_id", "T2"), ("student_id", "S9"),
                           ("t_event", c.now_ms() + 1)):
            p = one(V2, c, key); p[field] = val
            b = make_batch(V2, key, "T1", [p], c.now_ms(), "b")
            r = v.handle_batch(b, c.now_ms())
            self.assertEqual(r["results"][0]["status"], "rejected", field)

    def test_v1_status_tamper_with_recomputed_hash_is_accepted(self):
        """Documents the weakness of the v1 construction: hash is unkeyed and the token
        does not cover Status/Terminal_ID."""
        from lsasp.protocol import _v1_hash
        c, v, key = setup(V1)
        p = one(V1, c, key, status="late")
        p["status"] = "on_time"; p["hash"] = _v1_hash(p["token"], "on_time", p["terminal_id"])
        r = v.handle_batch(make_batch(V1, key, "T1", [p], c.now_ms(), "b"), c.now_ms())
        self.assertTrue(r["ok"])
        self.assertEqual(v.accepted_records[0]["status"], "on_time")

    def test_v2_duplicate_is_idempotent_not_double_counted(self):
        c, v, key = setup(V2)
        b = make_batch(V2, key, "T1", [one(V2, c, key)], c.now_ms(), "b")
        v.handle_batch(b, c.now_ms())
        b2 = make_batch(V2, key, "T1", b["records"], c.now_ms(), "b2")
        r = v.handle_batch(b2, c.now_ms())
        self.assertEqual(r["results"][0]["status"], "duplicate")
        self.assertEqual(len(v.accepted_records), 1)

    def test_v2_same_nonce_different_content_is_replay(self):
        c, v, key = setup(V2)
        p = one(V2, c, key)
        v.handle_batch(make_batch(V2, key, "T1", [p], c.now_ms(), "b"), c.now_ms())
        q = make_packet(V2, key, "S2", c.now_ms(), "late", "T1", nonce=p["nonce"])
        r = v.handle_batch(make_batch(V2, key, "T1", [q], c.now_ms(), "b2"), c.now_ms())
        self.assertEqual(r["results"][0]["reason"], "replay")

    def test_v2_per_record_and_permanent_flag(self):
        c, v, key = setup(V2)
        good = [one(V2, c, key) for _ in range(3)]
        bad = one(V2, c, key); bad["token"] = "00" * 32
        b = make_batch(V2, key, "T1", good[:1] + [bad] + good[1:], c.now_ms(), "b")
        r = v.handle_batch(b, c.now_ms())
        self.assertEqual([x["status"] for x in r["results"]], ["accepted", "rejected", "accepted", "accepted"])
        self.assertTrue(r["results"][1]["permanent"])

    def test_v1_whole_batch_rejected(self):
        c, v, key = setup(V1)
        good = [one(V1, c, key) for _ in range(3)]
        bad = one(V1, c, key); bad["token"] = "00" * 32
        r = v.handle_batch(make_batch(V1, key, "T1", good + [bad], c.now_ms(), "b"), c.now_ms())
        self.assertFalse(r["ok"]); self.assertEqual(len(v.accepted_records), 0)

    def test_v2_batch_stale_and_bad_mac_and_refresh_attack(self):
        c, v, key = setup(V2)
        b = make_batch(V2, key, "T1", [one(V2, c, key)], c.now_ms(), "b")
        c.advance_s(400)
        self.assertEqual(v.handle_batch(b, c.now_ms())["batch_error"], "stale_batch")
        b["t_tx"] = c.now_ms()                       # attacker refreshes T_tx without the key
        self.assertEqual(v.handle_batch(b, c.now_ms())["batch_error"], "bad_batch_mac")

    def test_v2_event_window(self):
        c, v, key = setup(V2)
        old = make_packet(V2, key, "S1", c.now_ms() - 25 * 3600 * 1000, "late", "T1")
        fut = make_packet(V2, key, "S1", c.now_ms() + 3600 * 1000, "late", "T1")
        ok = make_packet(V2, key, "S1", c.now_ms() - 3600 * 1000, "late", "T1")
        r = v.handle_batch(make_batch(V2, key, "T1", [old, fut, ok], c.now_ms(), "b"), c.now_ms())
        self.assertEqual([x["status"] for x in r["results"]], ["rejected", "rejected", "accepted"])

    def test_v2_terminal_isolation(self):
        c, v, key1 = setup(V2)
        key2 = terminal_key(V2, MASTER, "T2")
        p = make_packet(V2, key2, "S1", c.now_ms(), "late", "T2")
        r = v.handle_batch(make_batch(V2, key1, "T1", [p], c.now_ms(), "b"), c.now_ms())
        self.assertEqual(r["results"][0]["reason"], "terminal_mismatch")
        r = v.handle_batch(make_batch(V2, key2, "T9", [p], c.now_ms(), "b"), c.now_ms())
        self.assertIn(r["batch_error"], ("bad_batch_mac",))

    def test_persistent_nonce_survives_restart_memory_does_not(self):
        for cfg, expect_dup in ((V1, True), (V2, False)):
            c, v, key = setup(cfg)
            b = make_batch(cfg, key, "T1", [one(cfg, c, key)], c.now_ms(), "b")
            v.handle_batch(b, c.now_ms())
            v.restart()
            r = v.handle_batch(make_batch(cfg, key, "T1", b["records"], c.now_ms(), "b2"), c.now_ms())
            accepted_twice = len(v.accepted_records) == 2
            self.assertEqual(accepted_twice, expect_dup, cfg.name)

    def test_malformed_inputs_never_raise(self):
        rng = random.Random(1)
        for cfg in (V1, V2):
            c, v, key = setup(cfg)
            base = make_batch(cfg, key, "T1", [one(cfg, c, key)], c.now_ms(), "b")
            for _ in range(400):
                b = copy.deepcopy(base)
                kind = rng.randrange(6)
                rec = b["records"][0]
                if kind == 0: rec[rng.choice(list(rec))] = rng.choice([None, 1, "x", [], {}, 1.5, True])
                elif kind == 1: del rec[rng.choice(list(rec))]
                elif kind == 2: b["records"] = rng.choice([None, 5, "s", [None], [1], [[]]])
                elif kind == 3: b.pop(rng.choice(list(b)))
                elif kind == 4: b[rng.choice(list(b))] = rng.choice([None, 0, "", [], {}])
                else: rec["nonce"] = "zz" * 16
                try:
                    v.handle_batch(b, c.now_ms())
                except Exception as e:  # noqa: BLE001
                    self.fail(f"{cfg.name} raised {type(e).__name__}: {e} for {b}")

    def test_v1_freshness_variants(self):
        c, v, key = setup(variant(V1, one_sided_freshness=False))
        p = make_packet(V1, key, "S1", c.now_ms() + 3600 * 1000, "late", "T1")
        self.assertFalse(v.handle_batch(make_batch(V1, key, "T1", [p], c.now_ms(), "b"), c.now_ms())["ok"])
        c, v, key = setup(variant(V1, one_sided_freshness=True))
        p = make_packet(V1, key, "S1", c.now_ms() + 3600 * 1000, "late", "T1")
        self.assertTrue(v.handle_batch(make_batch(V1, key, "T1", [p], c.now_ms(), "b"), c.now_ms())["ok"])


if __name__ == "__main__":
    unittest.main()


class ExtraAttackTests(unittest.TestCase):
    def test_record_suppression_detected_only_by_v2(self):
        import random
        from experiments import suite as S
        for cfg, expect in ((V1, True), (V2, False)):
            self.assertEqual(S.a_record_suppression(S.Ctx(cfg, random.Random(1))), expect)

    def test_fuzz_never_crashes(self):
        import random
        from experiments import suite as S
        for cfg in (V1, V2):
            for i in range(50):
                self.assertFalse(S.a_fuzz_robustness(S.Ctx(cfg, random.Random(i))))
